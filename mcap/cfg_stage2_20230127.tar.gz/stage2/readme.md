Contents
--------
1. Supported Platforms
2. Summary
3. Install
4. Example
5. Component
6. Change history

## 1. Supported Platforms
	Module is tested on CentOS7(x86_64)(kernel 3.10.0-862.14.4.el7.x86_64)

## 2. Summary
	User can configure stage2 of production DRXP board FPGA by using this software.

## 3. Install
	This module needs pciutils-devel and systemd-devel package.
	Please install these packages before making binary.

 	 CentOS7:
 	  # yum install pciutils-devel
 	  # yum install systemd-devel
 	 RHEL7:
 	  # yum install pciutils-devel
 	  # yum install systemd-devel
 	  ( You may need to enable optional repository.
        Below command enables optional repository. 
        # subscription-manager repos --enable rhel-7-server-optional-rpms )
 

	After installing pciutils-devel package, please execute following command.
     $ cd ./mcap_src
	 $ make

## 4. Example
	User can configure the stage2 of production DRXP board by following command.
	Following example configure stage2 by using drxp_prod_2.bit file.

	 #./mcap -x 903F -y 0 -p ./drxp_prod_2.bit

## 5. Component
	.
	├── LICENSE_GPL
	├── license
	├── mcap_src
	│   ├── Makefile
	│   ├── mcap.c
	│   ├── mcap_lib.c
	│   └── mcap_lib.h
	└── readme.md
	
## 6. Change History
Jan 27, 2023; version 1.0.3
 - Fix the license description.





