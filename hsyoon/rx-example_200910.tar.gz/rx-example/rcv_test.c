#include <stdio.h>
#include <sys/eventfd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <endian.h>
#include <string.h>
#include <math.h> 

#include "drxpd.h"

#define OUTPUT_BIN_FILE "rcv_data.bin"
#define BLK_DATA_SIZE (4ULL*1024ULL*1024ULL) //(4 * 1024 * 1024)[1Block] * 35
#define GRP_DATA_SIZE (BLK_DATA_SIZE * 35ULL) //(4 * 1024 * 1024)[1Block] * 35
#define SMP_DATA_SIZE 48*3000000
#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

int error_check_flag = 0;
int data_check_flag = 0;
int rcv_stop_flag = 0;
int gi_dfd = -1;
static int gi_efd = -1;

void vSigCatch(int iSig) 
{
	const uint64_t u64_add_count = 0x00000000000000001;

	printf("\nstop receiving.\n");
	rcv_stop_flag = 1;

	if( gi_efd != -1 )
	{
		if ( write(gi_efd , &u64_add_count, sizeof(uint64_t)  ) != sizeof(uint64_t) )
		{
			printf("write error. %m\n");
		}	
	}

}

void *pattern_check( void *prm )
{
	unsigned char *tp = (unsigned char *) prm;
	int data_size = SMP_DATA_SIZE;
	int buf_size = GRP_DATA_SIZE;
  	unsigned char *data_buf = (unsigned char *)NULL;
  	unsigned long long tmp_val;
	unsigned long long count;

	data_buf = (unsigned char *)malloc( buf_size );
	if( data_buf == NULL )
	{
		printf("fail to allocate buffer for dumping received data. %m.\n");
		goto error;	
	}

	memcpy( data_buf, tp, buf_size );
	memcpy( &tmp_val, (data_buf + data_size), 8);
	count = tmp_val;

	FILE *bfp = (FILE*)NULL;
	bfp = fopen( OUTPUT_BIN_FILE, "wb" );
	if( NULL == bfp )
	{
		printf("fail to open file for dumping received data. %m.\n");
		goto error;
	}
		
	int res = fwrite( data_buf, sizeof(unsigned char), buf_size, bfp);
	fflush( bfp );
	if( 1 > res )
	{
		printf("fwrite failed. fail to write down the received data. %m.\n");
	}
	if( 0 != fclose(bfp) )
	{
		printf("fclose failed. %m. (rcv_data.bin).\n");
	}

	printf("dump received data successfully. tick count=%llu\n", count);

error:
	if( data_buf )
	{
		free( data_buf );
		data_buf = NULL;
	}
	data_check_flag = 0;
	return (void*)NULL;
}


int iCalcSigAvg ( ST_DRXPD_MONDAT stSigAvg )
{
	int i_sigavg = 0;
	unsigned char *puc_sigavg;

	puc_sigavg = (unsigned char*)&i_sigavg ;
	puc_sigavg[3] = 0;
	puc_sigavg[0] = stSigAvg.RdValue[2];
	puc_sigavg[1] = stSigAvg.RdValue[1];
	puc_sigavg[2] = stSigAvg.RdValue[0];
	
	return i_sigavg;
}

static void vUsage(void)
{
	printf("./rcv -n <device file no> -g <group num>\n");
}

int main( int argc, char *argv[] )
{
	int 		i_opt;
	int 		i_devno = -1;
	char 		sz_devname[16] = {0};

	unsigned long long ull_group_num = 16ULL;
	int 		i_ret = 0;
	int 		i_result = 0;

	int i_devfd = -1;
	unsigned char *mp = (unsigned char *)NULL;
	size_t	ring_buf_size = GRP_DATA_SIZE * ull_group_num;
	int i_efd = -1; 
	uint64_t u;

	int device_open_flag = 0;
	int data_mapping_flag = 0;
	int rcv_event_flag = 0;
	int data_rcv_flag = 0;

	uint64_t offset_group = GRP_DATA_SIZE;
	pthread_t pattern_check_th;
	int i_count = 0;

	while ( -1 != (i_opt = getopt(argc, argv, "g:n:")) ) 
	{
		switch (i_opt) 
		{
		case 'g': //set the number of buffer groups
			if( 16 == atoi(optarg) ){
				ull_group_num = 16ULL;
			}else if( 32 == atoi(optarg) ){
				ull_group_num = 32ULL;
			}else if( 64 == atoi(optarg) ){
				ull_group_num = 64ULL;
			}else{
				printf("-g option available value is 16, 32 or 64.\n");
				vUsage();
				return -1;
			}
			break;
		case 'n': //set the number of device file
			i_devno = atoi(optarg);
			if( i_devno < 0  || i_devno > 15 )
			{
				printf("please select device file from 0 to 15\n");
				vUsage();
				return -1;
			}	
			break;
		default: /* '?' */
			vUsage();
			return -1;
		}
	}

	if( i_devno == -1 )
	{
		vUsage();
		return -1;	
	}
	memset( sz_devname , 0x00, sizeof(sz_devname));
	snprintf( sz_devname , sizeof(sz_devname), "/dev/drxpd%d" , i_devno );

	// setup signal handler
	if ( SIG_ERR == signal(SIGINT, vSigCatch) ){
		printf("fail to set signal handler(SIGINT). %m\n");
		goto end;
	}

	// setup eventfd
	i_efd = eventfd(0, 0);
	if(i_efd < 0 ){
		printf("[%s] fail to open eventfd. %m\n", sz_devname);
		goto end;
	}
	gi_efd = i_efd;

	// open device file
	i_devfd = open( sz_devname, O_RDONLY );
	if( -1 == i_devfd ){
		printf("[%s] fail to open device file. %m\n", sz_devname);
		return (-1);
	}
	device_open_flag = 1;
	gi_dfd = i_devfd;

#define DFRSN
#if defined(DFRSN)
	ST_DRXPD_MONDAT st_dfrsn;

	st_dfrsn.ItemID = 0x00007fff;
	memset( st_dfrsn.RdValue, 0x00, 8 );
	ioctl( i_devfd, DRXPD_GET_MONSTS, &st_dfrsn );

	fprintf(stdout, "[%s] DFRSN SN=%02x%02x%02x, proto(0),prod(1)=%02x\n",
		sz_devname,
		st_dfrsn.RdValue[0],
		st_dfrsn.RdValue[1],
		st_dfrsn.RdValue[2],
		st_dfrsn.RdValue[3] ); //0=proto, 1=product
	fflush(stdout);
#endif // DFRVER)

#define DFRVER
#if defined(DFRVER)
	ST_DRXPD_MONDAT st_dfrver;

	st_dfrver.ItemID = 0x00007ff0;
	memset( st_dfrver.RdValue, 0x00, 8 );
	ioctl( i_devfd, DRXPD_GET_MONSTS, &st_dfrver );

	fprintf(stdout, "[%s] DFRVER driver=%02x.%02x.%02x, fpga=%02x%02x%02x%02x\n",
		sz_devname,
		st_dfrver.RdValue[0],
		st_dfrver.RdValue[1],
		st_dfrver.RdValue[2],
		st_dfrver.RdValue[4],
		st_dfrver.RdValue[5],
		st_dfrver.RdValue[6],
		st_dfrver.RdValue[7]);
	fflush(stdout);
#endif // DFRVER)

#define CHKSIGAVG
#if defined(CHKSIGAVG)
	ST_DRXPD_MONDAT st_sigavg_h;
	ST_DRXPD_MONDAT st_sigavg_m;
	ST_DRXPD_MONDAT st_sigavg_l;
	
	int i_sigavg_h = 0;
	int i_sigavg_m = 0;
	int i_sigavg_l = 0;
	
	int i_sigavg_err_h = 0;
	int i_sigavg_err_m = 0;
	int i_sigavg_err_l = 0;

	st_sigavg_h.ItemID = 0x00003102;
	st_sigavg_m.ItemID = 0x00003202;
	st_sigavg_l.ItemID = 0x00003302;
	memset( st_sigavg_h.RdValue, 0x00, 8 );
	memset( st_sigavg_m.RdValue, 0x00, 8 );
	memset( st_sigavg_l.RdValue, 0x00, 8 );

	ioctl( i_devfd, DRXPD_GET_MONSTS, &st_sigavg_h  );
	ioctl( i_devfd, DRXPD_GET_MONSTS, &st_sigavg_m  );
	ioctl( i_devfd, DRXPD_GET_MONSTS, &st_sigavg_l  );

	i_sigavg_h = iCalcSigAvg( st_sigavg_h);
	i_sigavg_m = iCalcSigAvg( st_sigavg_m);
	i_sigavg_l = iCalcSigAvg( st_sigavg_l);

	i_sigavg_err_h = st_sigavg_h.RdValue[3] & 0x01;
	i_sigavg_err_m = st_sigavg_m.RdValue[3] & 0x01;
	i_sigavg_err_l = st_sigavg_l.RdValue[3] & 0x01;

	fprintf( stderr, "[%s] SIGAVG hbit = %.02f[mW](%.02f[dBm]) , err=%d\n", 
			sz_devname,
			i_sigavg_h * 0.000001, 
			10.*log10(i_sigavg_h*0.000001),
			i_sigavg_err_h );
	fprintf( stderr, "[%s] SIGAVG mbit = %.02f[mW](%.02f[dBm]) , err=%d\n", 
			sz_devname,
			i_sigavg_m * 0.000001, 
			10.*log10((double)i_sigavg_m*0.000001),
			i_sigavg_err_m );
	fprintf( stderr, "[%s] SIGAVG lbit = %.02f[mW](%.02f[dBm]) , err=%d\n",
			sz_devname,
			i_sigavg_l * 0.000001, 
			10.*log10((double)i_sigavg_l*0.000001),
			i_sigavg_err_l );
#endif //#define CHKSIGAVG

	mp = mmap(NULL, ring_buf_size, PROT_READ , MAP_SHARED, i_devfd, 0);
	if( MAP_FAILED == (void*) mp )
	{
		printf("[%s] mmap failed. %m.\n", sz_devname);
		goto end;
	}
	data_mapping_flag = 1;

	// setup eventfd.
	if( 0 != ioctl(i_devfd, DRXPD_SET_RCVEVT, i_efd) )
	{
		printf("[%s] fail to setup eventfd. \n", sz_devname);
		goto end;
	}
	
	//call DRXPD_INIT
	i_ret = ioctl(i_devfd, DRXPD_INIT, &i_result) ;
	if( i_ret != 0  || i_result != 0 )
	{
		printf("[%s] ioctl(DRXPD_INIT) failed. %m. \n", sz_devname ); 
		goto end;
	}

	// start receive event 
	i_result = 0;
	i_ret = ioctl(i_devfd, DRXPD_RCVEVTSTART, &i_result) ;
	if( i_ret != 0 || i_result != 0 )
	{
		printf("[%s] ioctl(DRXPD_RCVEVTSTART) failed. %m.\n", sz_devname);
		goto end;
	}

	if( -1 == read(i_efd, &u, sizeof(uint64_t)) )
	{
		printf("[%s] fail to read eventfd.\n", sz_devname);
		fflush(stdout);
		goto end;
	}

	i_result = 0;
	if( 0 != ioctl(i_devfd, DRXPD_RCVSTART, &i_result) )
	{
		printf("[%s] ioctl(DRXPD_RCVSTART) failed. %m.\n", sz_devname ); 
		goto end;
	}
	
	// start receiving loop
	while( 0 == rcv_stop_flag )
	{

		if( 1 == error_check_flag )
		{
			printf("[%s] program encoutered error during receiving data.\n", sz_devname);
			goto end;
		}

		if( -1 == read(i_efd,&u,sizeof(uint64_t)) )
		{
			printf("[%s] fail to read eventfd. %m.\n", sz_devname);
			goto end;
		}

		//write down data ... 
		if( 0 == data_check_flag )
		{
			data_check_flag = 1;
		  	int i_res2 = pthread_create( &pattern_check_th, NULL, 
										pattern_check, (void*) (mp + i_count*offset_group) );
		  	if( -1 == i_res2 )
			{
		    	printf("[%s] fail to create pthread for dumping received data. %m.\n", sz_devname);
				data_check_flag = 0;
				goto end;
		  	}
        	
			int i_status = pthread_detach( pattern_check_th );
        	if (i_status != 0) 
			{
          		printf("[%s] failed to detatch pthread for dumping received data. %m.\n", sz_devname);
		  		goto end;
        	}
		}

		i_count++;
		if( ull_group_num == i_count )
		{
		  	i_count = 0;

			ST_DRXPD_MONDAT st_mon;
			float *pf_consumption= (float*)st_mon.RdValue;
			st_mon.ItemID = GET_CONSUMPTION_ID;
			memset( st_mon.RdValue, 0x00, 8 );
			ioctl( i_devfd, DRXPD_GET_MONSTS, &st_mon );
			printf("power consumption: %.1f [W]\n", *pf_consumption );
			fflush(stdout);

		}

	} // receive loop end

	while( 0 != data_check_flag )
	{
		printf("[%s] wating for pthread for dumping data finishes.\n", sz_devname);
		sleep( 1 );
	}
	sleep( 1 );

	if( 0 != ioctl(i_devfd, DRXPD_RCVSTOP, &i_result) )
	{
		printf("[%s] ioctl(DRXPD_RCVSTOP) failed. %m.\n", sz_devname);
		goto end;
	}

	if( 0 != ioctl(i_devfd, DRXPD_RCVEVTSTOP, &i_result) )
	{
		printf("[%s] ioctl(DRXPD_RCVEVTSTOP) failed. %m.\n", sz_devname);
		goto end;
	}

	if( 0 != munmap(mp, ring_buf_size) )
	{
		printf("[%s] muunmap failed. %m\n", sz_devname);
	}else{
		data_mapping_flag = 0;
	}

	if( 0 != close(i_devfd) )
	{
		printf("[%s] fail to close device file. %m.\n", sz_devname);
		return -1;
	}else{
		device_open_flag = 0;
	}

	return 0;

end:

	while( 0 != data_check_flag )
	{
		printf("[%s] wating for pthread for dumping data finishes.\n", sz_devname);
		sleep( 1 );
	}
	sleep( 1 );

	if( 1 == data_rcv_flag )
	{
		if( 0 != ioctl(i_devfd, DRXPD_RCVSTOP, &i_result) )
		{
			printf("[%s] ioctl(DRXPD_RCVSTOP) failed. %m.\n", sz_devname);
		}
	}

	if( 1 == rcv_event_flag )
	{
		if( 0 != ioctl(i_devfd, DRXPD_RCVEVTSTOP, &i_result) )
		{
			printf("[%s] ioctl(DRXPD_RCVEVTSTOP) failed. %m.\n", sz_devname);
		}
	}

	if( 1 == data_mapping_flag )
	{
		if( 0 != munmap(mp, ring_buf_size) )
		{
			printf("[%s] muunmap failed. %m\n", sz_devname);
		}
	}

	if( 1 == device_open_flag )
	{
		if( 0 != close( i_devfd ) )
		{
			printf("[%s] fail to close device file. %m.\n", sz_devname);
		}
	}
				
	return (-1);
		
}
