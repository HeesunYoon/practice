#include <stdio.h>
#include <sys/eventfd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <signal.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <errno.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <endian.h>
#include <string.h>
#include <math.h> 
#include <stdbool.h>

#include "drxpd.h"


int error_check_flag = 0;
int g_data_check_flag = 0;
int rcv_stop_flag = 0;
int gi_dfd = -1;
static int gi_efd = -1;


unsigned long ulTimCnv2Us(struct timespec *pstTs);
int iTimCalcDiff(struct timespec *pstBgn, struct timespec *pstEnd, struct timespec *pstDiff );
void vSigCatch(int iSig); 
void *pattern_check( void *prm );
static void vUsage(void);



#define REF_BIN_FILE "ref.bin"
#define OUTPUT_BIN_FILE "rcv_data.bin"
#define BLK_DATA_SIZE (4ULL*1024ULL*1024ULL) //(4 * 1024 * 1024)[1Block] * 35
#define GRP_DATA_SIZE (BLK_DATA_SIZE * 35ULL) //(4 * 1024 * 1024)[1Block] * 35
#define SMP_DATA_SIZE 48*3000000
#define likely(x) __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)


//
// #define MT(target, msg) 
//
//  A Macro for measuring runtime of a target part.
//  This macro measures the runitme when the target part is executed.
//	It printfs the measured runtime to the STDOUT.
//	It also prints msg to this log.
//
//	ex. MT( sleep(1), "The runtime of sleep(1)" )
//
//	 -> In this case, this macro measures the runtime of "sleep(1)".
//	    And it outputs following message to the STDOUT.
//
//		"[The runtime of sleep(1)] 1.001010203 sec"
//

#define MT(target, msg) \
	{ \
		struct timespec st_bgnsup, st_endsup, st_diffsup; \
		clock_gettime(CLOCK_REALTIME, &st_bgnsup ); \
		target; \
		clock_gettime(CLOCK_REALTIME, &st_endsup ); \
		iTimCalcDiff( &st_bgnsup, &st_endsup, &st_diffsup ); \
		printf("[%s] %ld.%09ld sec\n", msg, st_diffsup.tv_sec, st_diffsup.tv_nsec);\
	} 


unsigned int uiConvMtdly2uint ( unsigned char *pucMtdly )	
{
	unsigned int ui_meta= 0;
	unsigned char *puc_meta;

	puc_meta = (unsigned char*)&ui_meta; 

	puc_meta[0] = pucMtdly[3];
	puc_meta[1] = pucMtdly[2];
	puc_meta[2] = pucMtdly[1];
	puc_meta[3] = pucMtdly[0];

	return ui_meta;
}


void vSigCatch(int iSig) 
{
	const uint64_t u64_add_count = 0x00000000000000001;

	printf("\nstop receiving.\n");
	rcv_stop_flag = 1;

	if( gi_efd != -1 )
	{
		if ( write(gi_efd , &u64_add_count, sizeof(uint64_t)  ) != sizeof(uint64_t) )
		{
			printf("write error. %m\n");
		}	
	}

}

void *pattern_check( void *prm )
{
	unsigned char *tp = (unsigned char *) prm;
	int data_size = SMP_DATA_SIZE;
	int buf_size = GRP_DATA_SIZE;
  	unsigned char *data_buf = (unsigned char *)NULL;
  	unsigned long long tmp_val;
	unsigned long long count;
	FILE *bfp = (FILE*)NULL;

	int i_reffd = -1;
	unsigned char *puc_ref = (unsigned char*)-1;
	int i_cmp = -1;



	data_buf = (unsigned char *)malloc( buf_size );
	if( data_buf == NULL )
	{
		printf("fail to allocate buffer for dumping received data. %m.\n");
		goto error;	
	}

	memcpy( data_buf, tp, buf_size );
	memcpy( &tmp_val, (data_buf + data_size), 8);
	count = tmp_val;


	i_reffd = open(REF_BIN_FILE, O_RDONLY);
	if(i_reffd == -1 ){
		printf("fail to open reference binary file for comparing recevied data.\n");
		i_cmp = -1;
	}else{
		puc_ref = mmap(NULL, SMP_DATA_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE, i_reffd, 0);
		if( (void *) -1 == puc_ref ){
			printf("fail to mmap reference binary file for comparing recevied data.\n");
			close(i_reffd);
			i_reffd = -1;	
			goto dump;
		}	

		i_cmp = memcmp( data_buf, puc_ref, SMP_DATA_SIZE);
		if( 0 != munmap(puc_ref, SMP_DATA_SIZE) ){
		}

		close(i_reffd);
		i_reffd = -1;	
	}

dump:
	bfp = fopen( OUTPUT_BIN_FILE, "wb" );
	if( NULL == bfp )
	{
		printf("fail to open file for dumping received data. %m.\n");
		goto error;
	}
		
	int res = fwrite( data_buf, sizeof(unsigned char), buf_size, bfp);
	fflush( bfp );
	if( 1 > res )
	{
		printf("fwrite failed. fail to write down the received data. %m.\n");
	}
	if( 0 != fclose(bfp) )
	{
		printf("fclose failed. %m. (rcv_data.bin).\n");
	}

	printf("dump received data successfully. tick count=%llu. data check=%s.\n", count,
			i_cmp == 0 ? "OK" : "NG");


error:
	if( data_buf )
	{
		free( data_buf );
		data_buf = NULL;
	}
	g_data_check_flag = 0;
	return (void*)NULL;
}




static void vUsage(void)
{
	printf("./rcv -n <device file no> [-g <group num>] [-d] [-f <type>] \n");
	printf("-g: change the number of group buffer.\n");
	printf("-d: dump received data.\n");
	printf("-f <type>: enable forcetx capability.\n");
	printf("	1: normal.\n");
	printf("	2: prbs31. reset every 48ms.\n");
	printf("	3: prbs31.\n");
	printf("	4: prbs63.\n");
	printf("	5: prbs31. 3bit. reset every 48ms.\n");
	printf("	6: prbs31. 3bit.\n");
	printf("	7: prbs63. 3bit.\n");
	printf("	8: prbs63. reset every 48ms.\n");
	printf("	9: prbs63. 3bit. reset every 48ms.\n");
}

int main( int argc, char *argv[] )
{
	int 		i_opt;
	int 		i_devno = -1;
	char 		sz_devname[16] = {0};

	unsigned long long ull_group_num = 16ULL;
	int 		i_ret = 0;
	int 		i_result = 0;

	int i_devfd = -1;
	unsigned char *mp = (unsigned char *)NULL;
	size_t	ring_buf_size = GRP_DATA_SIZE * ull_group_num;
	int i_efd = -1; 
	uint64_t u;

	int device_open_flag = 0;
	int data_mapping_flag = 0;
	int rcv_event_flag = 0;
	int data_rcv_flag = 0;

	uint64_t offset_group = GRP_DATA_SIZE;
	pthread_t pattern_check_th;
	int i_count = 0;

	ST_DRXPD_RCVSTS st_status;
	int i = 0;
	
	bool b_dump_data = false;
	bool b_first_time = true;
	unsigned long long ull_tick = 0ULL;
	int i_cmp = 0;

	unsigned  int ui_count_te = 0;
	bool b_meta = false;
	ST_DRXPD_MONDAT st_hbit_mdly;
	ST_DRXPD_MONDAT st_mbit_mdly;
	ST_DRXPD_MONDAT st_lbit_mdly;

	unsigned int ui_hbit_mdly = 0;
	unsigned int ui_mbit_mdly = 0;
	unsigned int ui_lbit_mdly = 0;
	
	ST_METADELAY_BUF st_mt;
	int j = 0;
	unsigned long ul_usec = 0UL;
	static unsigned long ul_usec_bfr  = 0UL;
	unsigned long ul_usec_diff = 0UL;

	st_hbit_mdly.ItemID = 0x00001D06;
	st_mbit_mdly.ItemID = 0x00002D06;
	st_lbit_mdly.ItemID = 0x00003D06;


	int i_reffd = -1;
	bool b_compare = false;
	unsigned char *puc_ref = (unsigned char*)-1;

	bool b_force_tx = false;
	unsigned char uc_force_tx_type = 0;
	ST_DRXPD_CONTDAT st_con_forcetx ;

	while ( -1 != (i_opt = getopt(argc, argv, "g:n:f:dm")) ) 
	{
		switch (i_opt) 
		{
		case 'g': //set the number of buffer groups
			if( 16 == atoi(optarg) ){
				ull_group_num = 16ULL;
			}else if( 32 == atoi(optarg) ){
				ull_group_num = 32ULL;
			}else if( 64 == atoi(optarg) ){
				ull_group_num = 64ULL;
			}else{
				printf("-g option available value is 16, 32 or 64.\n");
				vUsage();
				return -1;
			}
			break;
		case 'n': //set the number of device file
			i_devno = atoi(optarg);
			if( i_devno < 0  || i_devno > 15 )
			{
				printf("please select device file from 0 to 15\n");
				vUsage();
				return -1;
			}	
			break;
		case 'd': //dump data
			b_dump_data = true;
			break;
		case 'f': //force tx
			b_force_tx = true;
			uc_force_tx_type = atoi(optarg);
			break;
		case 'm': //check meta-frame delay
			b_meta = true;
			break;
		default: /* '?' */
			vUsage();
			return -1;
		}
	}

	if( i_devno == -1 )
	{
		vUsage();
		return -1;	
	}
	memset( sz_devname , 0x00, sizeof(sz_devname));
	snprintf( sz_devname , sizeof(sz_devname), "/dev/drxpd%d" , i_devno );

	// setup signal handler
	if ( SIG_ERR == signal(SIGINT, vSigCatch) ){
		printf("fail to set signal handler(SIGINT). %m\n");
		goto end;
	}

	// open reference file
	i_reffd = open(REF_BIN_FILE, O_RDONLY);
	if(i_reffd == -1 ){
		printf("fail to open reference binary file for comparing recevied data.\n");
		b_compare = false;
	}else{
		b_compare = true;
		puc_ref = mmap(NULL, SMP_DATA_SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE, i_reffd, 0);
		if( (void *) -1 == puc_ref ){
			printf("fail to mmap reference binary file for comparing recevied data.\n");
			close(i_reffd);
			i_reffd = -1;	
			goto end;
		}	
	}

	// setup eventfd
	i_efd = eventfd(0, 0);
	if(i_efd < 0 ){
		printf("[%s] fail to open eventfd. %m\n", sz_devname);
		goto end;
	}
	gi_efd = i_efd;

	// open device file
	i_devfd = open( sz_devname, O_RDONLY );
	if( -1 == i_devfd ){
		printf("[%s] fail to open device file. %m\n", sz_devname);
		return (-1);
	}
	device_open_flag = 1;
	gi_dfd = i_devfd;

	mp = mmap(NULL, ring_buf_size, PROT_READ , MAP_SHARED, i_devfd, 0);
	if( MAP_FAILED == (void*) mp )
	{
		printf("[%s] mmap failed. %m.\n", sz_devname);
		goto end;
	}
	data_mapping_flag = 1;

	// setup eventfd.
	MT( (i_ret = ioctl(i_devfd, DRXPD_SET_RCVEVT, i_efd)) , "DRXPD_SET_RCVEVT");
	if( 0 != i_ret ) 
	{
		printf("[%s] fail to setup eventfd. \n", sz_devname);
		goto end;
	}
	
	//call DRXPD_INIT
	MT( (i_ret = ioctl(i_devfd, DRXPD_INIT, &i_result)) , "DRXPD_INIT(RECEPT)");
	if( i_ret != 0  || i_result != 0 )
	{
		printf("[%s] ioctl(DRXPD_INIT) failed. %m. \n", sz_devname ); 
		goto end;
	}

	// start receive event 
	i_result = 0;
	MT( (i_ret = ioctl(i_devfd, DRXPD_RCVEVTSTART, &i_result)), "DRXPD_RCVEVTSTART" );
	if( i_ret != 0 || i_result != 0 )
	{
		printf("[%s] ioctl(DRXPD_RCVEVTSTART) failed. %m.\n", sz_devname);
		goto end;
	}

	if( -1 == read(i_efd, &u, sizeof(uint64_t)) )
	{
		printf("[%s] fail to read eventfd.\n", sz_devname);
		fflush(stdout);
		goto end;
	}


	if(b_force_tx){
		st_con_forcetx.ItemID 		= SET_DFR_FORCETX_ID; 
		memset(st_con_forcetx.WrValue, 0x00, sizeof(st_con_forcetx.WrValue));
		st_con_forcetx.WrValue[0] = DFRFORCETX_ENABLE; 
		st_con_forcetx.WrValue[4] = uc_force_tx_type;
		i_ret = ioctl( i_devfd, DRXPD_SET_CONTROL, &st_con_forcetx); 
		if( i_ret < 0 ) {
			printf("[%s] SET_FORCE_TX is failed. %m\n", sz_devname );
		}
	}

	// clear all buffer status
	i_ret = ioctl(i_devfd, DRXPD_GET_RCVSTS, &st_status);
	for(i=0; i < st_status.GroupNum; i++){
		i_ret = ioctl(i_devfd, DRXPD_CLR_RCV, i);
	}

	i_result = 0;
	MT( (i_ret = ioctl(i_devfd, DRXPD_RCVSTART, &i_result)) , "DRXPD_RCVSTART");
	if( 0 != i_ret ) 
	{
		printf("[%s] ioctl(DRXPD_RCVSTART) failed. %m.\n", sz_devname ); 
		goto end;
	}
	data_rcv_flag = 1;


	// start receiving loop
	while( 0 == rcv_stop_flag )
	{

		if( 1 == error_check_flag )
		{
			printf("[%s] program encoutered error during receiving data.\n", sz_devname);
			goto end;
		}

		if( -1 == read(i_efd,&u,sizeof(uint64_t)) )
		{
			printf("[%s] fail to read eventfd. %m.\n", sz_devname);
			goto end;
		}

		// get current buffer status
		i_ret = ioctl(i_devfd, DRXPD_GET_RCVSTS, &st_status);
		if( b_first_time ){
			b_first_time = false;
			for(i=0; i < st_status.GroupNum; i++)
			{
				if( st_status.Group[i%st_status.GroupNum] == 1 /*DRXPD_COMPLETE*/ &&
					st_status.Group[(i+1)%st_status.GroupNum] == 256 /*IDLE_WR*/ ){
					i_count = i;
					break;
				}
			}	
			
		}
	
		if( b_dump_data ){
			//write down data ... 
			if( 0 == g_data_check_flag )
			{
				g_data_check_flag = 1;
			  	int i_res2 = pthread_create( &pattern_check_th, NULL, 
											pattern_check, (void*) (mp + i_count*offset_group) );
			  	if( -1 == i_res2 )
				{
			    	printf("[%s] fail to create pthread for dumping received data. %m.\n", sz_devname);
					g_data_check_flag = 0;
					goto end;
			  	}
        		
				int i_status = pthread_detach( pattern_check_th );
        		if (i_status != 0) 
				{
        	  		printf("[%s] fail to detatch pthread for dumping received data. %m.\n", sz_devname);
			  		goto end;
        		}
			}

		}else if(b_compare){
			i_cmp = memcmp( (mp + i_count*offset_group) , puc_ref, SMP_DATA_SIZE);
			memcpy( &ull_tick		, (mp + i_count*offset_group) + SMP_DATA_SIZE    , 8);
			printf("tick count=%llu, data check=%s.\n", 
					ull_tick, i_cmp == 0 ? "OK" : "NG" );
			//clear buffer status
			i_ret = ioctl(i_devfd, DRXPD_CLR_RCV, i_count);
		}else{
			// do nothing
		}


		ui_count_te++;
		if( (ui_count_te % 22 == 0) && b_meta ){

			memset( st_hbit_mdly.RdValue, 0x00, 8 );
			memset( st_mbit_mdly.RdValue, 0x00, 8 );
			memset( st_lbit_mdly.RdValue, 0x00, 8 );

			i_ret = ioctl(i_devfd, DRXPD_GET_MONSTS, &st_hbit_mdly );
			if( i_ret != 0 ){ 
				printf("fail to get metaframe delay(h)\n");
			}else{
				ui_hbit_mdly = uiConvMtdly2uint( st_hbit_mdly.RdValue );
				printf("[GET_DFR_METAFRAME_DELAY] hbit :: count(200MHz)=%u, delay(us)=%f\n", 
					ui_hbit_mdly, (float)ui_hbit_mdly*0.005 );
			}

			i_ret = ioctl( i_devfd, DRXPD_GET_MONSTS, &st_mbit_mdly );
			if( i_ret != 0 ){
				printf("fail to get metaframe delay(m)\n");
			}else{
				ui_mbit_mdly = uiConvMtdly2uint( st_mbit_mdly.RdValue );
				printf("[GET_DFR_METAFRAME_DELAY] mbit :: count(200MHz)=%u, delay(us)=%f\n", 
					ui_mbit_mdly, (float)ui_mbit_mdly*0.005 );

			}

			i_ret = ioctl( i_devfd, DRXPD_GET_MONSTS, &st_lbit_mdly );
			if( i_ret != 0 ){ 
				printf("fail to get metaframe delay(l)\n");
			}else{
				ui_lbit_mdly = uiConvMtdly2uint( st_lbit_mdly.RdValue );
				printf("[GET_DFR_METAFRAME_DELAY] lbit :: count(200MHz)=%u, delay(us)=%f\n", 
					ui_lbit_mdly, (float)ui_lbit_mdly*0.005 );
			}
			printf("\n");

			memset(&st_mt, 0x00, sizeof(ST_METADELAY_BUF));
			i_ret = ioctl(i_devfd, DRXPD_GET_METADELAY, &st_mt); 
			if( i_ret != 0 ){
				printf("fail to get metaframe information from device driver buffer.\n");
			}else{
				for(j=0; j<st_mt.uiNumCopied; j++){
					ui_hbit_mdly = uiConvMtdly2uint( (unsigned char *)&st_mt.uiDelayD[j] );
					ui_mbit_mdly = uiConvMtdly2uint( (unsigned char *)&st_mt.uiDelayC[j] );
					ui_lbit_mdly = uiConvMtdly2uint( (unsigned char *)&st_mt.uiDelayB[j] );
					ul_usec = ulTimCnv2Us(&st_mt.stTime[j]);
					ul_usec_diff = ul_usec - ul_usec_bfr;
					ul_usec_bfr = ul_usec;
					printf("[DRXPD_GET_METADELAY] [%d]: l=%f(us), m=%f(us), h=%f(us), %lu(us) elapsed previous entry.\n", 
											j,
											(float)ui_lbit_mdly*0.005,
											(float)ui_mbit_mdly*0.005,
											(float)ui_hbit_mdly*0.005,
											ul_usec_diff);
				}	
				printf("[DRXPD_GET_METADELAY]: %u data was copied.\n\n", st_mt.uiNumCopied); 
			}
		}


		i_count ++;
		if( ull_group_num == i_count ){
		  	i_count = 0;
		}

	} // receive loop end


	while( 0 != g_data_check_flag && b_dump_data )
	{
		printf("[%s] wating for pthread for dumping data finishes.\n", sz_devname);
		sleep( 1 );
	}
	sleep( 1 );

	MT( (i_ret = ioctl(i_devfd, DRXPD_RCVSTOP, &i_result)), "DRXPD_RCVSTOP");
	if( 0 != i_ret ) 
	{
		printf("[%s] ioctl(DRXPD_RCVSTOP) failed. %m.\n", sz_devname);
		goto end;
	}

	MT( (i_ret = ioctl(i_devfd, DRXPD_RCVEVTSTOP, &i_result)), "DRXPD_RCVEVTSTOP");
	if( 0 != i_ret ) 
	{
		printf("[%s] ioctl(DRXPD_RCVEVTSTOP) failed. %m.\n", sz_devname);
		goto end;
	}

	if( 0 != munmap(mp, ring_buf_size) )
	{
		printf("[%s] muunmap failed. %m\n", sz_devname);
	}else{
		data_mapping_flag = 0;
	}


	if( b_force_tx ){
		st_con_forcetx.ItemID 		= SET_DFR_FORCETX_ID; 
		memset(st_con_forcetx.WrValue, 0x00, sizeof(st_con_forcetx.WrValue));
		st_con_forcetx.WrValue[0] 	= DFRFORCETX_DISABLE; 
		st_con_forcetx.WrValue[4] 	= DFRFORCETX_OBS; 
		i_ret = ioctl( i_devfd, DRXPD_SET_CONTROL, &st_con_forcetx); 
		if( i_ret < 0 ) {
			printf("[%s] SET_FORCE_TX is failed. %m\n", sz_devname );
		}
	}

	if( 0 != close(i_devfd) )
	{
		printf("[%s] fail to close device file. %m.\n", sz_devname);
		return -1;
	}else{
		device_open_flag = 0;
	}

	return 0;

end:

	if( (void *) -1 != puc_ref ){
		if( 0 != munmap(puc_ref, SMP_DATA_SIZE) ){
		}
		puc_ref =  (unsigned char *) -1;
	}
	if( i_reffd != -1 ){
		close(i_reffd);
		i_reffd = -1;	
	}


	while( 0 != g_data_check_flag && b_dump_data )
	{
		printf("[%s] wating for pthread for dumping data finishes.\n", sz_devname);
		sleep( 1 );
	}
	sleep( 1 );

	if( 1 == data_rcv_flag )
	{
		if( 0 != ioctl(i_devfd, DRXPD_RCVSTOP, &i_result) )
		{
			printf("[%s] ioctl(DRXPD_RCVSTOP) failed. %m.\n", sz_devname);
		}
	}

	if( 1 == rcv_event_flag )
	{
		if( 0 != ioctl(i_devfd, DRXPD_RCVEVTSTOP, &i_result) )
		{
			printf("[%s] ioctl(DRXPD_RCVEVTSTOP) failed. %m.\n", sz_devname);
		}
	}

	if( 1 == data_mapping_flag )
	{
		if( 0 != munmap(mp, ring_buf_size) )
		{
			printf("[%s] muunmap failed. %m\n", sz_devname);
		}
	}

	if( 1 == device_open_flag )
	{
		if( 0 != close( i_devfd ) )
		{
			printf("[%s] fail to close device file. %m.\n", sz_devname);
		}
	}
				
	return (-1);
		
}


int iTimCalcDiff( struct timespec *pstBgn, struct timespec *pstEnd, 
					 struct timespec *pstDiff )
{
	long l_nsec = 0;
	long l_sec = 0;

	l_nsec = (pstEnd->tv_nsec - pstBgn->tv_nsec);
	l_sec  = (pstEnd->tv_sec  - pstBgn->tv_sec);

	//check time order
	if( l_sec < 0 ) 				return -1;
	if( l_sec == 0 && l_nsec < 0 ) 	return -1;

	if ( l_nsec < 0 ) {	
		l_nsec += 1000000000L;
		l_sec -= 1;
	}

	pstDiff->tv_sec 	= (time_t)l_sec;
	pstDiff->tv_nsec	= l_nsec;

	return 0;
}


unsigned long ulTimCnv2Us(struct timespec *pstTs)
{
	unsigned long ul_us = 0UL;

	ul_us = pstTs->tv_sec * 1000000UL;
	ul_us += (pstTs->tv_nsec / 1000UL);
	return ul_us;
}




