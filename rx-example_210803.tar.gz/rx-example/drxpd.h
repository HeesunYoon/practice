/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright(c) 2016 - 2021 Elecs Industry Co., Ltd. */

#ifndef _DRXPD_H_
#define _DRXPD_H_

#define STR_HELPER(x) #x
#define STR(x) STR_HELPER(x)

//VERSION
#define DRXPD_VERSION_MAJOR 2
#define DRXPD_VERSION_MINOR 0
#define DRXPD_VERSION_MICRO 12
#define DRXPD_VERSION_STRING STR(DRXPD_VERSION_MAJOR) "." STR(DRXPD_VERSION_MINOR) "." STR(DRXPD_VERSION_MICRO)

//Target board revision
#define DRXPD_PROTOTYPE 0
#define DRXPD_PRODUCT 1

//
// bug fix
//
#define JAN12_OVERRUN 	
#define JAN12_HANGUP 	
#define JAN12_INFOFRM 	
#define JAN18_RXFIFO	
//#define JAN18_RXFIFO_CHK // for check , don't use this define for release build
#define AUG30_ADD_DEFINE
#define AUG30_CHG_I2CMON_PERIOD
#define AUG30_CHG_TIMSTM_FORMAT
#define AUG30_CLR_DEBPRINT
#define AUG30_CHKSUM64
#define AUG30_AVOID_CLEAR_REG
#define SEP12_CHG_MAXBRDNUM
#define SEP12_FPGA_TEMP
#define NOV14_CHKSUM64
#define NOV14_RESET_SYNCERR
#define DEC26_SEU_EVFD
#define DEC26_SEU_IOCTL
#define DEC26_SEU_KTHRD
#define FEB21_SEU_ELPS
#define OCT10_EQCTL
#define OCT18_RSTEQSTS
#define OCT18_RSTBUFSTS
#define OCT25_GTRST



//
// register  i/o map
//

#define BAR0_OFT_VER 				0x00000000
#define BAR0_OFT_FUSE 				0x00000010
#define BAR0_OFT_RESET 				0x00000018
#define BAR0_OFT_USR_ACCESS 		0x00000028

#define BAR0_OFT_DMACRL 		0x00000300
#define BAR0_DMACTL_EN			0x00000001	//1:active, 0:
#define BAR0_DMACTL_RW			0x00000002	//1:read 0:write
#define BAR0_DMACTL_RIMSK		0x00000004	//1:enable recv comp interrupt 0:disable
#define BAR0_DMACTL_STS			0x00000010  //1:DMA is already started 0:DMA is stopped
#define BAR0_DMACTL_RINT		0x00000040	//1:DMA interrupt occerred 0:
#define BAR0_DMACTL_TXEN		0x00000100	//1:SEND, 0:STOP
#define BAR0_DMACTL_RSIZ_SET(dmactl, val) 	((uint8_t)dmactl + 2) = (val & 0x3FFF)
#define BAR0_DMACTL_RSIZ_GET(dmactl) 		(*((uint8_t)dmactl + 2) & 0x3FFF )

#define BAR0_OFT_DMA_DSC_SET	0x00000308
#define BAR0_DMA_DSC_SET_LD	0x00000001	//1:request to retrive addr list, 0:
#define BAR0_DMA_DSC_SET_RSLT	0x00000010	//1:retrive comp, 0:
#define BAR0_DMA_DSC_SET_NUM_SET(dmadsc, val) ((*(uint32_t*)dmadsc) |=(uint32_t)((val<<16) & 0x0fff0000 ))
#define BAR0_DMA_DSC_SET_NUM_GET(dmadsc)	  *(uint16_t*)((uint8_t*)dmadsc + 2)

#define BAR0_OFT_DMA_DSC_ADD	0x00000310
#define BAR0_DMA_DSC_ADD_SET( dmaadd, val)	  *((uint64_t*)dmaadd ) = val
#define BAR0_DMA_DSC_ADD_GET( dmaadd )		  *((uint64_t*)dmaadd )

#define BAR0_OFT_DMA_WR_ADD		0x00000318
#define BAR0_OFT_DMA_WR_ADD_SET( dmawr, val)  *((uint64_t*)dmawr ) = val
#define BAR0_OFT_DMA_WR_ADD_GET( dmawr )	  *((uint64_t*)dmawr )

#define BAR0_OFT_48MS_EVT	0x00000208
#define BAR0_48MS_EVT_EN	0x00000001
#define BAR0_48MS_EVT_SYNC	0x00000002

#define BAR0_OFT_DMA_DT_SEL			0x00000320
#define BAR0_DMA_DT_SEL_SEL2_B		0x00010000
#define BAR0_DMA_DT_SEL_SEL2_C		0x00000100
#define BAR0_DMA_DT_SEL_SEL2_D		0x00000001


#define BAR0_OFT_ALMA_GTX			0x00003600	//all reset
#define BAR0_ALMA_GTX_ALL_RST		0x00000001	//1:reset 0:

#define BAR0_OFT_ALMA_GTX_DONE		0x00003618
#define BAR0_ALMA_GTX_DONE_RXDONE	0x00000001
#define BAR0_ALMA_GTX_DONE_TXDONE	0x00000010

#define BAR0_OFT_GTX_TRX_RST		0x00003610

#define BAR0_OFT_DTSEL		0x00000320
#define BAR0_OFT_FIXDAT1D	0x00000328
#define BAR0_OFT_FIXDAT2D	0x00000330
#define BAR0_OFT_FIXDAT1C	0x00000338
#define BAR0_OFT_FIXDAT2C	0x00000340
#define BAR0_OFT_FIXDAT1B	0x00000348
#define BAR0_OFT_FIXDAT2B	0x00000350


#define BAR0_OFT_GTX_QPLL_LOCK		0x00003608
#define GTX_QPLL_LOCK_LOCK			0x00000010
#define GTX_QPLL_LOCK_DEBLOCK		0x00000001


#define BAR0_OFT_GTX_AUTO_RESET_DISABLE		0x00003678
#define GTX_AUTO_RESET_DISABLE				0x00000001


#define BAR0_OFT_ASTE_TX_CFG	0x00003000
#define ASTE_TX_CFG_RESET		0x0001 


#define BAR0_OFT_DMACTL_TX_SIZ 0x00000370




//
// data structure
//

typedef enum tagDrxpNumOfGroups
{
	DRXPD_GRP16		= 16,
	DRXPD_GRP32		= 32,
	DRXPD_GRP64		= 64,
	DRXPD_GRPMIN	= 16,
	DRXPD_GRPMAX	= 64,
	DRXPD_GRPTRS	= 1,
}EN_NUMGROUPS;


typedef struct tagDrxpBufferGroupStatus
{
#define DRXPD_STOP			0
#define DRXPD_START			1
	int				State;
	int				GroupNum;
#define DRXPD_IDLE 			0
#define DRXPD_IDLE_WR		256
#define DRXPD_COMPLETE		1
#define DRXPD_OVERRUN		2
#define DRXPD_OVERRUN_WR	258
//#define DRXPD_GRPMAX
	int				Group[DRXPD_GRPMAX];

}ST_DRXPD_RCVSTS;


typedef struct drxpd_snd_sts 
{
//already defined 
//#define DRXPD_STOP			0
#define DRXPD_RUN			1
	int State;
	
}ST_DRXPD_SNDSTS;



//
//	return value
//
#define DRXPD_OK 0
#define DRXPD_NG -1
#define DRXPD_OVH -2



//
// io control command
//

#define DRXPD_INIT 			10	//intialize device
#define DRXPD_SET_RCVEVT 	12	//setup eventfd
#define DRXPD_RCVEVTSTART 	15	//start receiving 48ms interrupt
#define DRXPD_RCVEVTSTOP 	16	//stop receiving 48ms interrupt
#define DRXPD_RCVSTART 		17	//start receiving packet
#define DRXPD_RCVSTOP 		18	//stop receiving packet
#define DRXPD_GET_RCVSTS 	19	//show status
#define DRXPD_CLR_RCV 		20	//clear status
#define DRXPD_SNDSTOP 		21	//stop sending packet
#define DRXPD_SNDSTART		22
#define DRXPD_GET_SNDSTS 	23	//show status
#define DRXPD_SET_SNDSIZ 	24	//
#define DRXPD_RCVGROUPS 	25	//
// Driver specification ver2.0.5 also changed 
#define DRXPD_SET_RCVGROUPS 	DRXPD_RCVGROUPS	

#if defined(DEC26_SEU_EVFD)
#define DRXPD_SET_SEUEVT	26  // setup evnetfd for seu event
#endif //defined(DEC26_SEU_EVFD)

#if defined(OCT10_EQCTL)
#define DRXPD_SEL_EQ		27 //control equalizer mode
#define DRXPD_GET_EQ		28 //control equalizer mode
#endif //defined(OCT10_EQCTL)

#define DRXPD_FLASH_OVHLOG 	29 // flash eeprom ovh log

#define DRXPD_GET_OVRFLW 	30 // get device ring buffer state

#define DRXPD_GET_METADELAY	31



//for debug
#define DRXPD_DEBOFT		100
#define DRXPD_CLR_RCVEVT 	(DRXPD_DEBOFT + 3)	//clear eventfd	(debug)
#define DRXPD_SIG_RCVEVT 	(DRXPD_DEBOFT + 4)	//inform event manualy (debug) Argument = num of event
#define DRXPD_DDR_RX		(DRXPD_DEBOFT + 5) 
#if defined(DEC26_SEU_EVFD)
#define DRXPD_CLR_SEUEVT	(DRXPD_DEBOFT + 6)  // setup evnetfd for seu event
#define DRXPD_SND_SEUMSG	(DRXPD_DEBOFT + 7)  // 
#define DRXPD_RCV_SEUMSG	(DRXPD_DEBOFT + 8)  // 
#define DRXPD_STOP_SEUKTHRD	(DRXPD_DEBOFT + 9)  // 
#define DRXPD_START_SEUKTHRD (DRXPD_DEBOFT + 10)  // 
#endif //defined(DEC26_SEU_EVFD)

//return values
#define DRXP_OK			(0)		//Transmission has stopped
#define DRXP_NG_MODE 	(-2)	//It has not been open in O_WRONLY
#define DRXP_NG_BUSY	(-3)	//Transmission has already been stopped
#define DRXP_NG			(-1)	//Other failure
#define DRXP_NG_INIT	(-4)	//It has not been initialized

#if defined(AUG30_ADD_DEFINE)
#define DRXPD_NG_MODE	(-2)
#define DRXPD_NG_BUSY	(-3)
#define DRXPD_NG_INIT	(-4)
#define DRXPD_SND_MIN	(48)
#define DRXPD_SND_MAX	(144000000)
#endif // defined(AUG30_ADD_DEFINE)

//command ID
#define DRXPD_GET_MONSTS	1001
#define DRXPD_SET_CONTROL	1002
#define DRXPD_GET_I2C_DATA	1003
#define DRXPD_SET_I2C_CMD	1004
#define RD_IO	1005
#define WR_IO	1006

//Monitoring Items
//GET_ALARM_STATUS_REG
#define GET_ALM_STS_REG_ID_D 0x3100
#define GET_ALM_STS_REG_ID_C 0x3200
#define GET_ALM_STS_REG_ID_B 0x3300

//GET_POWER_ALARM_REG
#define GET_POW_ALM_REG_ID_D 0x3101
#define GET_POW_ALM_REG_ID_C 0x3201
#define GET_POW_ALM_REG_ID_B 0x3301

//GET_SIGNAL_AVG_nW
#define GET_SIG_AVG_ID_D 0x3102
#define GET_SIG_AVG_ID_C 0x3202
#define GET_SIG_AVG_ID_B 0x3302

//GET_DFR_STATUS
#define GET_DFR_STS_ID 0x3801
#define GET_DFR_STS 0x0200
#define SYNC_PTN_DTC_D 0x3308
#define SYNC_PTN_DTC_C 0x3408
#define SYNC_PTN_DTC_B 0x3508
#define MASK_SYNC_PTN_DTC 0x40

//GET_DFR_VOLTAGE_STATUS
#define GET_DFR_VOL_STS_ID 0x3802
#define GET_DFR_VOL_STS 0x01F8

//GET_DFR_CHKSUM_COUNTER
#define GET_DFR_CHK_CNT_ID_D 0x1805
#define GET_DFR_CHK_CNT_ID_C 0x2805
#define GET_DFR_CHK_CNT_ID_B 0x3805
#define GET_DFR_CHK_CNT_D 0x3310
#define GET_DFR_CHK_CNT_C 0x3410
#define GET_DFR_CHK_CNT_B 0x3510

//GET_DFR_SYNC_ERR_CNT
#define GET_DFR_SYNC_ERR_CNT_ID_D 0x1D01
#define GET_DFR_SYNC_ERR_CNT_ID_C 0x2D01
#define GET_DFR_SYNC_ERR_CNT_ID_B 0x3D01
#define GET_DFR_SYNC_ERR_CNT_H_D 0x3398
#define GET_DFR_SYNC_ERR_CNT_H_C 0x3498
#define GET_DFR_SYNC_ERR_CNT_H_B 0x3598
#define GET_DFR_SYNC_ERR_CNT_L_D 0x33A0
#define GET_DFR_SYNC_ERR_CNT_L_C 0x34A0
#define GET_DFR_SYNC_ERR_CNT_L_B 0x35A0

//GET_DFR_SYNC_STATUS
#define GET_DFR_SYNC_STS_ID_D 0x1D03
#define GET_DFR_SYNC_STS_ID_C 0x2D03
#define GET_DFR_SYNC_STS_ID_B 0x3D03
#define GET_DFR_SYNC_STS_D 0x33A8
#define GET_DFR_SYNC_STS_C 0x34A8
#define GET_DFR_SYNC_STS_B 0x35A8

//GET_DFR_TEST_DATA
#define GET_DFR_TST_DAT_ID_D 0x1D04
#define GET_DFR_TST_DAT_ID_C 0x2D04
#define GET_DFR_TST_DAT_ID_B 0x3D04

//GET_DFR_METAFRAME_DELAY
#define GET_DFR_MTFRM_DLY_ID_D 0x1D06
#define GET_DFR_MTFRM_DLY_ID_C 0x2D06
#define GET_DFR_MTFRM_DLY_ID_B 0x3D06
#define GET_DFR_MTFRM_DLY_D 0x0220
#define GET_DFR_MTFRM_DLY_C 0x0228
#define GET_DFR_MTFRM_DLY_B 0x0230

//GET_DFR_SN
#define GET_DFR_SN_ID 0x7FFF
#define GET_DFR_SN 0x0010

//GET_DFR_VER
#define GET_DFR_VER_ID 0x7FF0
#define GET_DFR_VER 0x0000

#if defined( SEP12_FPGA_TEMP)
#define GET_FPGA_TEMP_ID 0x3808
#define GET_FPGA_TEMP 0x0100
#endif //defined( SEP12_FPGA_TEMP)

#if defined(DEC26_SEU_IOCTL)
#define GET_SEU_STATUS_ID 	0x0E00
#define GET_SEU_ERRCNT_ID	0x0E01
#define GET_SEU_ELAPSED_ID	0x0E02
#define GET_SEU_DIGERR_ID	0x0E03
#define GET_SEU_DIAERRCNT_ID	GET_SEU_DIGERR_ID
#endif //defined(DEC26_SEU_IOCTL)

#define GET_OVH_THRESHOLD_ID 0x0F00
#define GET_OVH_FLG_ID 		 0x0F01
#define GET_OVH_LOG_ID 		 0x0F02

//FORCE_TX
#define GET_DFR_FORCETX_ID	 0x1F00

//Control Items
//DFR_RESET
#define DFR_RST_ID_D 0x9000
#define DFR_RST_ID_C 0xA000
#define DFR_RST_ID_B 0xB000
#define DFR_RST_ID_ALL 0xC000
#define DFR_RESET 0x0018

// Driver specification ver2.0.5 also changed 
#define RST_DFR_ID_D	DFR_RST_ID_D
#define RST_DFR_ID_C	DFR_RST_ID_C
#define RST_DFR_ID_B	DFR_RST_ID_B
#define RST_DFR_ID_ALL	DFR_RST_ID_ALL

#if 1 //add sano 19/01/11
#define IF_RESET 0x0030
#endif

//RESET_DFR_CHKSUM
#define RST_DFR_CHK_ID_D 0x9502
#define RST_DFR_CHK_ID_C 0xA502
#define RST_DFR_CHK_ID_B 0xB502
#define RST_DFR_CHK_ID_ALL 0xC502
#define RST_DFR_CHK_D 0x3310
#define RST_DFR_CHK_C 0x3410
#define RST_DFR_CHK_B 0x3510

//RESET_DFR_SYNC
#define RST_DFR_SYNC_ID_D 0x9507
#define RST_DFR_SYNC_ID_C 0xA507
#define RST_DFR_SYNC_ID_B 0xB507
#define RST_DFR_SYNC_ID_ALL 0xC507
#define RST_DFR_SYNC_D 0x3390
#define RST_DFR_SYNC_C 0x3490
#define RST_DFR_SYNC_B 0x3590

//DFR_TEST_DATA
#define DFR_TST_DAT_ID_D 0x9509
#define DFR_TST_DAT_ID_C 0xA509
#define DFR_TST_DAT_ID_B 0xB509
#define DFR_TST_DAT_ID_ALL 0xC509
// Driver specification ver2.0.5 also changed 
#define SET_DFR_TST_DAT_ID_D	DFR_TST_DAT_ID_D
#define SET_DFR_TST_DAT_ID_C	DFR_TST_DAT_ID_C
#define SET_DFR_TST_DAT_ID_B	DFR_TST_DAT_ID_B
#define SET_DFR_TST_DAT_ID_ALL	DFR_TST_DAT_ID_ALL
#define DMA_DT_SEL 0x0320
#define DMA_FIXDAT1_D 0x0328 
#define DMA_FIXDAT2_D 0x0330 
#define DMA_FIXDAT1_C 0x0338 
#define DMA_FIXDAT2_C 0x0340 
#define DMA_FIXDAT1_B 0x0348 
#define DMA_FIXDAT2_B 0x0350 

//INSERT_SYNCPTN_ERR
#define INS_SYNC_ERR_ID_D 0x950A
#define INS_SYNC_ERR_ID_C 0xA50A
#define INS_SYNC_ERR_ID_B 0xB50A
#define INS_SYNC_ERR_ID_ALL 0xC50A
#define INS_SYNC_ERR_H_A 0x3288
#define INS_SYNC_ERR_L_M 0x3290
#define INS_ERR_PTN_NUM 0x03

//SET_CHKSUM_ERR
#define SET_CHK_ERR_ID_D 0x950B
#define SET_CHK_ERR_ID_C 0xA50B
#define SET_CHK_ERR_ID_B 0xB50B
#define SET_CHK_ERR_ID_ALL 0xC50B
#define SET_CHK_ERR 0x3298

//SET_SQCNT_ERR
#define SET_SQ_ERR_ID_D 0x950C
#define SET_SQ_ERR_ID_C 0xA50C
#define SET_SQ_ERR_ID_B 0xB50C
#define SET_SQ_ERR_ID_ALL 0xC50C
#define SET_SQ_ERR 0x32A0

#if defined(DEC26_SEU_IOCTL)
#define SET_SEU_STATUS_ID	0x0E04
#define SET_SEU_INJERR_ID	0x0E05
#define SET_SEU_RSTELPS_ID	0x0E06
#define SET_SEU_RSTCNT_ID	0x0E07
#define SET_SEU_RSTERR_ID	0x0E08
#endif //defined(DEC26_SEU_IOCTL)

//FORCE_TX
#define SET_DFR_FORCETX_ID	 0x2F00

//PARITY_RANGE
#define GET_PARITY_RANGE_ID 0x1F01
#define SET_PARITY_RANGE_ID 0x2F01

//???̑?
//I2C
#define I2C_START_D 0x000001
#define I2C_START_C 0x000100
#define I2C_START_B 0x010000
#define I2C_CHK_D 0x00000C
#define I2C_CHK_C 0x000C00
#define I2C_CHK_B 0x0C0000
#define I2C_RD 0x1
#define I2C_WR 0x0
#define I2C_ADDR_A0 0xA0
#define I2C_ADDR_A2 0xA2

//IO Address for I2C
#define I2C_CTL_IO 0x3808
#define I2C_ADDR_IO_D 0x3810
#define I2C_ADDR_IO_C 0x3818
#define I2C_ADDR_IO_B 0x3820
#define I2C_DP_W_IO_D 0x3828
#define I2C_DP_W_IO_C 0x3858
#define I2C_DP_W_IO_B 0x3888
#define I2C_DT_W_IO_D 0x3830
#define I2C_DT_W_IO_C 0x3860
#define I2C_DT_W_IO_B 0x3890
#define I2C_DP_R_IO_D 0x3840
#define I2C_DP_R_IO_C 0x3870
#define I2C_DP_R_IO_B 0x38A0
#define I2C_DT_R_IO_D 0x3848
#define I2C_DT_R_IO_C 0x3878
#define I2C_DT_R_IO_B 0x38A8

#if defined(DEC26_SEU_IOCTL)
#define SEU_STATUS		0x3C00
#define SEU_ERROR		0x3C08
#define SEU_ERR_CNT0	0x3C10
#define SEU_ERR_CNT1	0x3C18
#define SEU_ERR_CNTCTL	0x3C20
#define SEU_TX_CTL		0x3C28
#define SEU_TX_MSG		0x3C30
#define SEU_RX_CTL		0x3C40
#define SEU_RX_MSG		0x3C48
#define SEU_ELAPS		0x3C58
#define SEU_ELAPSCTL	0x3C60
#define SEU_INTRCTL		0x3C68
#define SEU_INTRFCT		0x3C70
#define SEU_CMDCTL		0x3C78
#define SEU_CMDCODE		0x3C80
#define SEU_DIGCNT 		0x3c88
#define SEU_DIGCTL 		0x3c90
#endif //defined(DEC27_SEU_IOCTL)

#define SET_OVH_THRESHOLD_ID 0x3B00

#if 1 //add_p3 sano 19/01/11
#define GET_CONSUMPTION_ID			0x3900
#define GET_CONSUMPTION				0x0158
#define GET_MTFRM_ERR_ID_D			0x3A00
#define GET_MTFRM_ERR_ID_C			0x3A10
#define GET_MTFRM_ERR_ID_B			0x3A20
#define GET_MTFRM_ERR				0x000033D8
#endif


#if defined(OCT10_EQCTL)
#define DRXPD_SEL_EQ_DFE 100
#define DRXPD_SEL_EQ_LPM 101
#endif //defined(OCT10_EQCTL)

// User IF
#define DFRFORCETX_UNKNOWN   0x00
#define DFRFORCETX_ENABLE    0x01
#define DFRFORCETX_DISABLE   0x02

#define DFRFORCETX_OBS	     0x01
#define DFRFORCETX_PRBS	     0x02
#define DFRFORCETX_PRBS31R	 0x02
#define DFRFORCETX_PRBS31	 0x03
#define DFRFORCETX_PRBS63    0x04
#define DFRFORCETX_PRBS31SR  0x05
#define DFRFORCETX_PRBS31S   0x06
#define DFRFORCETX_PRBS63S   0x07
#define DFRFORCETX_PRBS63R   0x08
#define DFRFORCETX_PRBS63SR  0x09

// IO data
#define FORCETX_OBS				0x00 //ddr
#define FORCETX_PRBS31_48MS		0x01 //prbs31. reset generator every 48ms.
#define FORCETX_FIX_H1M0L0		0x02 //fix pattern. h=1/m=0/l=0
#define FORCETX_FIX_H0M1L0		0x03 //fix pattern. h=0/m=1/l=0
#define FORCETX_FIX_H0M0L1		0x04 //fix pattern. h=0/m=0/l=1
#define FORCETX_FIX_X1Y0		0x05 //fix pattern. polx=1/poly=0 
#define FORCETX_PRBS31			0x06 //prbs31. don't reset generator. 
#define FORCETX_PRBS63			0x07 //prbs63. don't reset generator. 
#define FORCETX_PRBS31S_48MS 	0x08 //prbs31. 3bit unit. reset generator every 48ms. 
#define FORCETX_PRBS31S 		0x09 //prbs31. 3bit unit. 
#define FORCETX_PRBS63S			0x0A //prbs63. 3bit unit.
#define FORCETX_PRBS63R			0x0B //prbs63. reset generator every 48ms. 
#define FORCETX_PRBS63SR		0x0C //prbs63. 3bit unit. reset generator every 48ms.
//  end






//another
#define OK 0
#define NG -1
#define SIZE_8BIT	8
#define SIZE_16BIT	16
#define SIZE_32BIT	32
#define SIZE_64BIT	64
#define SIZE_2BYTE	2
#define SIZE_4BYTE	4
#define SIZE_8BYTE	8
#define SIZE_16BYTE	16
#define BIT_D 0
#define BIT_C 1
#define BIT_B 2
#define BIT_ALL 3
#define PROTOTYPE 0x0
#define PRODUCT 0x1
#define RESET 0x1
#define RESET_SYNC 0x3
#define MASK_ALM_TEMP 		0xC0	//(Byte0,7-6bit)
#define MASK_ALM_VOL 		0x30	//(Byte0,5-4bit)
#define MASK_ALM_TXBIAS 	0x0C	//(Byte0,3-2bit)
#define MASK_ALM_TXPOW 		0x03	//(Byte0,1-0bit)
#define MASK_ALM_RXPOW 		0xC0	//(Byte1,7-6bit)
#define MASK_WARN_TEMP 		0xC0	//(Byte5,7-6bit)
#define MASK_WARN_VOL		0x30	//(Byte5,5-4bit)
#define MASK_WARN_TXBIAS	0x0C	//(Byte5,3-2bit)
#define MASK_WARN_TXPOW		0x03	//(Byte5,1-0bit)
#define MASK_WARN_RXPOW 	0xC0	//(Byte6,7-6bit)
#define BIT_0 0x01
#define BIT_1 0x02
#define BIT_2 0x04
#define BIT_3 0x08
#define BIT_4 0x10
#define BIT_5 0x20
#define BIT_6 0x40
#define BIT_7 0x80
#define TEST_ID_0	0x0
#define TEST_ID_1	0x1
#define TEST_ID_2	0x2
#define TEST_ID_3	0x3
#define TEST_ID_4	0x4
#define TEST_ID_5	0x5
#define TEST_ID_6	0x6
#define TEST_ID_7	0x7
#define TEST_ID_8	0x8
#define TEST_ID_9	0x9
#define TEST_ID_10	0xA
#define TEST_ID_11	0xB
#define TEST_ID_12	0xC
#define TEST_ID_13	0xD
#define TEST_ID_14	0xE
#define TEST_ID_15	0xF
#define END_H	0x00002
#define END_M	0x00200
#define END_L	0x20000
#define TBL_END	-1
#define UNUSED	0
#define SFP_NUM 3
#define MAX_SIZE 96
//#define INTERRUPT_CNT 3
//#define KERNEL_RD 0
//#define USER_RD 1
//#define USER_WR 2
#define VALID 0
#define INVALID 1
#define TIME_OUT 50	//time_out = 20msec ?~ TIME_OUT

#if defined(AUG30_CLR_DEBPRINT )
//#define DEBUG 1
#else //defined(AUG30_CLR_DEBPRINT )
#define DEBUG 1
#endif //defined(AUG30_CLR_DEBPRINT )

#if defined(DEC26_SEU_IOCTL)

#define SEU_BITERR_HEARTBEART		0x00008000
#define SEU_BITERR_HEARTBEART_S		0x00004000
//#define SEU_BITERR_WD_OBS			0x00000000
//#define SEU_BITERR_WD_DET			0x00000200
//#define SEU_BITERR_WD_DET_S		0x00000100
#define SEU_BITERR_WD_CLA			0x00000080
#define SEU_BITERR_WD_CLA_S			0x00000040
#define SEU_BITERR_WD_COR			0x00000020
#define SEU_BITERR_WD_COR_S			0x00000010

#define SEU_BITSTS_INITIALIZATION	0x00008000
#define SEU_BITSTS_OBSERVATION		0x00004000
#define SEU_BITSTS_CORRECTION		0x00002000
#define SEU_BITSTS_CLASSIFICATION	0x00001000
#define SEU_BITSTS_INJECTION		0x00000800
#define SEU_BITSTS_DETECTONLY		0x00000400
#define SEU_BITSTS_DIAGNOSTICSCAN	0x00000200
#define SEU_BITSTS_IDLE				0x00000000	
#define SEU_BITSTS_ERROR			0x00000080

#define SEU_STATUS_INITIALIZATION	1	
#define SEU_STATUS_OBSERVATION		2
#define SEU_STATUS_CORRECTION		3
#define SEU_STATUS_CLASSIFICATION	4 //dont use
#define SEU_STATUS_INJECTION		5
#define SEU_STATUS_DETECTONLY		6
#define SEU_STATUS_DIAGNOSTICSCAN	7
#define SEU_STATUS_IDLE				8
#define SEU_STATUS_ERROR			9

#define SEU_ERRFCT_ERRORSTATUS	0x0000000000000001
#define SEU_ERRFCT_TIMEOUT		0x0000000000000002
#define SEU_ERRFCT_CORERR		0x0000000000000004
#define SEU_ERRFCT_UNCORERR		0x0000000000000008

#endif //defined(DEC26_SEU_IOCTL)


// device ring buffer status flag
#define DRXPD_DRB_OVRFLW 	1
#define DRXPD_DRB_NORMAL 	0


//for monitoring
typedef struct drxpd_mon_dat{
	int ItemID;
	unsigned char RdValue[8];
}ST_DRXPD_MONDAT;

//for control
typedef struct drxpd_cont_dat{
	int ItemID;
	unsigned char WrValue[8];
}ST_DRXPD_CONTDAT;

//I2C_Read for Debug
typedef struct drxpd_i2crd_dat{
	char result;
	unsigned char sfp_no;
	unsigned char i2c_address;
	unsigned char data_address;
	unsigned char length;
	unsigned char RdValue[96];
}ST_DRXPD_I2CRD;

//I2C_Write for Debug
typedef struct drxpd_i2c_cmd{
	char result;
	unsigned char sfp_no;
	unsigned char i2c_address;
	unsigned char data_address;
	unsigned char length;
	unsigned char WrValue[96];
}ST_DRXPD_I2CCMD;

#if 1	//2016/09/27 Y.Chikahiro add
typedef struct drxpd_rd_dat{
	int io_address;
	unsigned char access_size;
	unsigned char RdValue[8];
}ST_DRXPD_RDDAT;

typedef struct drxpd_wr_dat{
	int io_address;
	unsigned char access_size;
	unsigned char WrValue[8];
}ST_DRXPD_WRDAT;
#endif	//2016/09/27 Y.Chikahiro add

#if defined(DEC26_SEU_IOCTL)
typedef struct tagSeuStatus 
{
	unsigned int uiStatus;
	unsigned int uiError;
}ST_SEU_STATUS;
#define SEU_STATUS_INITIALIZER {.uiStatus=0, uiStatus=0}

typedef struct tagSeuErrCnt
{
	unsigned int uiCorErrCnt;
	unsigned int uiUnCorErrCnt;
}ST_SEU_ERRCNT;
#define SEU_ERRCNT_INITIALIZER {.usCorErrCnt=0, usUnCorErrCnt=0}

typedef struct tagSeuElpsedTime
{
	unsigned int   uiTot;
	unsigned int   uiObs;
}ST_SEU_ELPSD;
#define SEU_ELPSD_INITIALIZER {.uiObs=0, uiTot=0}
#endif //defined(DEC26_SEU_IOCTL)

#define MAX_METADELAY_BUF (64)
typedef struct tagMetaDelayInfo{
	unsigned int uiDelayB[MAX_METADELAY_BUF];
	unsigned int uiDelayC[MAX_METADELAY_BUF];
	unsigned int uiDelayD[MAX_METADELAY_BUF];
	struct timespec stTime[MAX_METADELAY_BUF];
	unsigned int uiNumCopied;
}ST_METADELAY_BUF;



#endif //_DRXPD_H_
