
./flash_write -m FLS -f <binary file> -d <device number>

ex.
 writing binary file, "drxp_production.bin", to /dev/drxpd2

	./flash_write -m FLS -f drxp_production.bin -d 2




