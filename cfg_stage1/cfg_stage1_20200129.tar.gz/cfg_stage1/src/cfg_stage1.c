/**@module@*********************************************************************

	Project : DRXP 
	Target	: DRXP Board Config FPGA-Flash

	Author	: k.shimoyama
	Date	: 2016/10/13

	@name	: cfg_stage1.c
 	@summary:driver source file

*********************************************************************@module@**/
/*- Revision History -----------------------------------------------------
	VER0.0.1 [2016/10/13]
------------------------------------------------------------------------*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>
#include <syslog.h>
#include <stdint.h>
#include <time.h>
//#include <openssl/md5.h>

#include "drxpd.h"

#define SND_BUF_SIZE 146800640
#ifndef DRXPD_SND_MAX
#define DRXPD_SND_MAX 144000000
#endif

// /dev/drxpdX (X=0,1,2,...,15)
#define MAX_DEVNO 15
#define MIN_DEVNO 0

#define FILESIZE 10000000 //config file max size

//Error code for syslog
enum {
	ERR_NON = 0,
	ERR_CMD_SET_SNDSIZ,
	ERR_WR_CFGMODE,
	ERR_RD_CFGMODE,
	ERR_CMD_INIT,
	ERR_WR_FIFO,
	ERR_WR_SETSIZE,
	ERR_WR_SNDSTT,
	ERR_WR_SNDSTP,
	ERR_WR_FLS,
	ERR_RD_FLS,		//10
	ERR_WR_CHKSUM,
	ERR_RD_CHKSUM,
	ERR_TMO,
	ERR_SUMCHK,
	ERR_WRFLS_FIN,
/* If you add an error, add it here.*/	
	ERR_KIND_MAX
};
// usage
static char gsz_help_msg[] =
"cfg_stage1 version 1.0.1\n"
"Usage: cfg_stage1 -n <device file number> -f <configuration file>\n"
"\n"
"Options:\n"
"\t-n <device file number> (0,1,2, ...,15) (MANDATORY)\n"
"\t  \tSpecify the board through device file number.\n"
"\t  \tThis option value corresponds to the index of device file.\n"
"\t  \tFor example, if you want to specify \"/dev/drxpd3\", please specify 3 to this option.\n"
"\t  \tOne production DRXP baord has two device files.\n"
"\t  \tIn this option please use young number for specifying the production DRXP board.\n"
"\t  \tFor exampe, in the case that your system has two production DRXP boards,\n"
"\t  \tfour device files are created. (/dev/drxpd0, /dev/drxpd1, /dev/drxpd2 and /dev/drxpd3).\n"
"\t  \t/dev/drxpd[0,1] corresponds to one board. /dev/drxpd[2,3] corresponds to another.\n"
"\t  \tIf you want to specify the latter board, please specify 2 to this option.\n"
"\t  \tPlease don't use 3.\n"
"\n"
"\t-f <configuration file> (255 characters) (MANDATORY)\n"
"\t  \tSpecify the file path to configuration file.\n"
"\n"
;

unsigned char guc_buf[FILESIZE] = {0};

char *modtime = (char*)NULL;
struct stat sb;
uint64_t ui64_sn;
char cMd5Buf[256] = {0};
int i_err = ERR_NON;
int device_no = -1;
char config_file[256];
int file_size = 0;




static void vUsage(void)
{
	fprintf(stdout,"%s", gsz_help_msg);
}

void vOutErrSyslog( int iErr )
{
	switch( iErr ) {
		case ERR_CMD_SET_SNDSIZ:
		case ERR_WR_CFGMODE:
		case ERR_RD_CFGMODE:
		case ERR_CMD_INIT:
		case ERR_WR_FIFO:
		case ERR_WR_SETSIZE:
		case ERR_WR_SNDSTT:
		case ERR_WR_SNDSTP:
		case ERR_WR_CHKSUM:
		case ERR_RD_CHKSUM:
		case ERR_WR_FLS:
		case ERR_RD_FLS:
			syslog(LOG_INFO,"[%d] Error occured during setting. -device_file[#%d] -S/N[%lu] -name[%s] -size[%d]byte -mtime[%s] -md5sum[%s]"
					 ,iErr, device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
			break;
		case ERR_TMO:
			syslog(LOG_INFO,"[%d] Timeout error occured during calculate checksum. -device_file[#%d] -S/N[%lu] -name[%s] -size[%d]byte -mtime[%s] -md5sum[%s]"
					 ,iErr, device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
			break;
		case ERR_SUMCHK:
			syslog(LOG_INFO,"[%d] Checksum value error. -device_file[#%d] -S/N[%lu] -name[%s] -size[%d]byte -mtime[%s] -md5sum[%s]"
					 ,iErr, device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
			break;
		case ERR_WRFLS_FIN:
			syslog(LOG_INFO,"[%d] Config flush write error. -device_file[#%d] -S/N[%lu] -name[%s] -size[%d]byte -mtime[%s] -md5sum[%s]"
					 ,iErr, device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
			break;
		default: 
			syslog(LOG_INFO,"[%d] Undefined error detect. -device_file[#%d] -S/N[%lu] -name[%s] -size[%d]byte -mtime[%s] -md5sum[%s]"
				 ,iErr, device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
			break;
	}
}

void vTrim( char *cStr )
{
	char *p;
	p = strchr( cStr, '\n' );
	if ( p != NULL ) *p='\0';
}
#if 0
//Calc md5sum
int iCalcMD5(unsigned char *ucSrc, size_t szSiz, char *ucBuf )
{
	MD5_CTX ctx;
	FILE *fp = (FILE*)NULL;
	size_t sz_t = 0;
	int i_ret = 0;
	int i = 0;
	char c_fin[33] = {0};
	unsigned char uc_tmpMD5[MD5_DIGEST_LENGTH] = {0};

	fp = fopen( ucSrc, "rb" );
	if ( fp == NULL ) return -1;

	i_ret = MD5_Init( &ctx );
	if ( i_ret != 1 ) return -1;

	sz_t = fread( guc_buf, sizeof(char), szSiz, fp );
	if ( sz_t < 0 ) return -1;

	i_ret = MD5_Update( &ctx, guc_buf, sz_t );
	if ( i_ret != 1 ) return -1;

	i_ret = MD5_Final( uc_tmpMD5, &ctx );
	if ( i_ret != 1 ) return -1;

	for( i=0; i<16; i++){
		sprintf( &c_fin[i * 2], "%02x", (unsigned int)uc_tmpMD5[i] );
	}
	memcpy(ucBuf, c_fin, sizeof(c_fin));

	return 0;
}
#else
//Check md5sum
int iChkMD5(char *ucSrc, char *ucBuf )
{
	FILE *fp = (FILE*)NULL;
	char cmd[256] = {0};
	char rdbuf[256] = {0};

	memset(rdbuf, 0, sizeof(rdbuf));
	sprintf(cmd, "md5sum %s", ucSrc);

	fp = popen( cmd, "r" );
	if ( fp == NULL ) 
	{
		fprintf(stderr,"popen error.\n");
		return -1;
	}
	fgets( rdbuf, sizeof(rdbuf), fp );
	if ( strlen(rdbuf) <= 0 ) {
		fprintf(stderr,"Error. can't create md5sum.\n");
		return -1;
	}
	memcpy( ucBuf, rdbuf, 32 );
	if ( fp ) {
		pclose( fp );
		fp = (FILE *)NULL;
	}
	return 0;
}
#endif
//Read serial number
int iGetDfrSn(int iFd, uint64_t *pui64Sn )
{
	int i_ret = 0;
	ST_DRXPD_MONDAT st_mon;

	st_mon.ItemID = GET_DFR_SN_ID;
	memset( st_mon.RdValue, 0x00, 8);

	i_ret = ioctl(iFd, DRXPD_GET_MONSTS, &st_mon);
	if (i_ret == -1) return -1;
	*pui64Sn = 0;
	*pui64Sn |= (uint64_t)(st_mon.RdValue[0] & 0x0000FF);
	*pui64Sn = *pui64Sn << 8;
	*pui64Sn |= (uint64_t)(st_mon.RdValue[1] & 0x0000FF);
	*pui64Sn = *pui64Sn << 8;
	*pui64Sn |= (uint64_t)(st_mon.RdValue[2] & 0x0000FF);
	return 0;
}

//Read board type
//1:Product
//0:Prototype
int iGetDfrBrdTyp(int iFd, int *puiBrdTyp )
{
	int i_ret = 0;
	ST_DRXPD_MONDAT st_mon;

	st_mon.ItemID = GET_DFR_SN_ID;
	memset( st_mon.RdValue, 0x00, 8);

	i_ret = ioctl(iFd, DRXPD_GET_MONSTS, &st_mon);
	if (i_ret == -1) return -1;
	*puiBrdTyp = (int32_t)(st_mon.RdValue[3] & 0x01);
	return 0;
}

//Read IF number
//1:IF2
//0:IF1
int iGetDfrIfnum(int iFd, int *puiIf )
{
	int i_ret = 0;
	ST_DRXPD_MONDAT st_mon;

	st_mon.ItemID = GET_DFR_SN_ID;
	memset( st_mon.RdValue, 0x00, 8);

	i_ret = ioctl(iFd, DRXPD_GET_MONSTS, &st_mon);
	if (i_ret == -1) return -1;
	*puiIf = (int32_t)(st_mon.RdValue[4] & 0x01);
	return 0;
}

//IOWrite
int iWrIO(int dfd, unsigned int offset, int size, void *pval)
{
	ST_DRXPD_WRDAT     wrdat;

	if((size != 16) && (size != 32) && (size != 64)){
		fprintf(stderr,"Write IO prm error!\n");
		return -1;
	}
	
	wrdat.io_address = offset;
	wrdat.access_size = (unsigned char)(size/8);
	memcpy(&wrdat.WrValue[0],pval,size/8);
	if(ioctl( dfd, WR_IO, &wrdat ) < 0){
		fprintf(stderr,"write IO error!\n");
		return -1;
	}else{
		return 0;
	}

}
//IORead
int iRdIO(int dfd,unsigned int offset, int size, void *pval)
{
	ST_DRXPD_RDDAT     rddat;

	if((size != 16) && (size != 32) && (size != 64)){
		fprintf(stderr,"Raed IO prm error!\n");
		return -1;
	}
	rddat.io_address = offset;
	rddat.access_size = (unsigned char)(size/8);
	if(ioctl( dfd, RD_IO, &rddat ) < 0){
		fprintf(stderr,"read IO error!\n");
		memset(pval,0,size/8);
		return -1;
	}else{
		memcpy(pval,&rddat.RdValue[0],size/8);
		return 0;
	}
}

//
//main
//
int main( int argc, char *argv[] ){

	int opt;
//	int device_no = -1;
//	char config_file[256];
	FILE *infp = NULL;
	int dfd = -1;
	unsigned char *mp = NULL;
	int ret = -1;
//	int file_size = 0;
	unsigned short io_data16 = 0;
	unsigned short io_data16_bk = 0;
	unsigned int io_data32 = 0;
	int result = 0;
	int tmo = 0;
	char devpath[32] = {0};
	int i_brdtyp = 0;
	int i_ifnum  = 0;

#define CHECK_TICK (1000*1000)	//1s
#define CHECK_TMO  (30)			//30s


	memset(config_file,0,sizeof(config_file));
	while ((opt = getopt(argc, argv, "n:f:")) != -1) {
		switch (opt) {
			case 'n':
				device_no=atoi(optarg);	
				if( (device_no < MIN_DEVNO) || (device_no > MAX_DEVNO) ){
				    vUsage();
					return ret; //ng
				}
				break;
			case 'f':
				strncpy(config_file,optarg,sizeof(config_file)-1);
				break;
			default: /* '?' */
				vUsage();
				return ret; 
		}   
	}  

	if(( device_no == -1) || ( strlen(config_file) <= 0 )){
	  vUsage();
	  return ret;
	}

	//config file open!
	infp = fopen(config_file,"rb");
	if( infp == NULL ){
		fprintf(stderr,"%s:file open error\n",config_file);
		return  ret;
	}
	
	//device open!
	if( snprintf(devpath, sizeof(devpath), "/dev/drxpd%d", device_no) < 0 )
	{
		fprintf(stderr, "fail to create device path string.\n");
		goto end;	
	}
	dfd = open( devpath, O_RDWR );
	if( dfd == -1 ){
		fprintf(stderr,"device%d:open error.(path:%s).\n",device_no, devpath);
		goto end;
	}

	if( iGetDfrSn( dfd, &ui64_sn ) == -1 ){
		fprintf(stderr,"device%d:get board serial number error.\n",device_no);
		goto end;
	}

	//check board type
	if( iGetDfrBrdTyp( dfd, &i_brdtyp ) == -1 ){
		fprintf(stderr,"device%d:get board type error.\n",device_no);
		goto end;	
	}
	if( i_brdtyp == 1 /*product*/ ){
		if( iGetDfrIfnum( dfd, &i_ifnum ) == -1){
			fprintf(stderr,"device%d:get if number error.\n",device_no);
			goto end;	
		}
		if( i_ifnum == 1 /*IF2*/ ){
			fprintf(stderr,"device%d:please use IF1 device file to specify the board.\n"
						,device_no);
			goto end;	
		}
	}

	if( stat(config_file,&sb) == -1 ){
		fprintf(stderr,"device%d:get file stat error.\n",device_no);
		goto end;
	}
#if 0
	if( iCalcMD5( config_file, (size_t)sb.st_size, cMd5Buf ) == -1 ){
		fprintf(stderr,"device%d:calcurate md5sum error.\n",device_no);
		goto end;
	}
#else
	if( iChkMD5( config_file, cMd5Buf ) == -1 ){
		fprintf(stderr,"device%d:md5sum error.\n",device_no);
		goto end;
	}
	modtime = ctime((&sb.st_mtime));
	vTrim( modtime );
#endif
	//mmap!
	mp = mmap(NULL, SND_BUF_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, dfd, 0); 
	if( mp == (void *) -1){
		mp = NULL;
		fprintf(stderr,"device%d:mmap error\n",device_no);
		goto end;
	}
	//config data copy!
	file_size = fread( mp, sizeof(unsigned char), SND_BUF_SIZE, infp );
	if(ferror(infp)){
		fprintf(stderr,"%s:file read error\n",config_file);
		goto end;
	}else{
		fprintf(stdout,"config file is %s:size = %d byte\n",config_file,file_size);
	}
	//send size set!
	if( ioctl(dfd, DRXPD_SET_SNDSIZ, DRXPD_SND_MAX ) == -1){
		fprintf(stderr,"device%d:ioctl(DRXPD_SET_SNDSIZ) error\n",device_no);
		i_err = ERR_CMD_SET_SNDSIZ;
		goto end;
	}

	//config mode set!
	io_data16 = (unsigned short)0x0001;
	if(iWrIO(dfd, 0x378, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(CONFIG MODE) error\n",device_no);
		i_err = ERR_WR_CFGMODE;
		goto end;
	}
	io_data16 = 0;
	if(iRdIO(dfd, 0x378, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Read IO(CONFIG MODE) error\n",device_no);
		i_err = ERR_RD_CFGMODE;
		goto end;
	}else{
		if(io_data16 != 0x0001){
			fprintf(stderr,"device%d:Read IO(CONFIG MODE) verify error\n",device_no);
			i_err = ERR_RD_CFGMODE;
			goto end;
		}else{
			fprintf(stdout,"device%d:Read IO(CONFIG MODE) set ok\n",device_no);
		}
	}
	
	if( ioctl(dfd, DRXPD_INIT, &result ) == -1){
		fprintf(stderr,"device%d:ioctl(DRXPD_INIT) error\n",device_no);
		i_err = ERR_CMD_INIT;
		goto end;
	}
	if(result == -1){
		fprintf(stderr,"device%d:ioctl(DRXPD_INIT) result error\n",device_no);
		i_err = ERR_CMD_INIT;
		goto end;
	}
	//fifo reset
	io_data16 = (unsigned short)0x80bc;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		i_err = ERR_WR_FIFO;
		goto end;
	}
	io_data16 = (unsigned short)0x0000;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		i_err = ERR_WR_FIFO;
		goto end;
	}
	io_data32 = (unsigned int)file_size;
	if(iWrIO(dfd, 0x4018, 32, &io_data32) == -1){
		fprintf(stderr,"device%d:Write IO(SIZE_SET) error\n",device_no);
		i_err = ERR_WR_SETSIZE;
		goto end;
	}
	io_data16 = (unsigned short)0x0000;
	if(iRdIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND_START) error\n",device_no);
		i_err = ERR_WR_SNDSTT;
		goto end;
	}
	
	io_data16 = (unsigned short)0x0103;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND START) error\n",device_no);
		i_err = ERR_WR_SNDSTT;
		goto end;
	}

	//sumcheck
	io_data16 = (unsigned short)0x0023; //clear chksum result bit, select checksum, start checksum 
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SUM_CHECK) error\n",device_no);
		i_err = ERR_WR_CHKSUM;
		goto end;
	}
	//wait
	for(tmo = 0; tmo < CHECK_TMO; tmo ++){
		usleep(CHECK_TICK);
		io_data16 = (unsigned short)0x0000;
		if(iRdIO(dfd, 0x4000, 16, &io_data16) == -1){
			fprintf(stderr,"device%d:Read IO(SUM_CHECK) error\n",device_no);
			i_err = ERR_RD_CHKSUM;
			goto end;
		}
		if((io_data16 & 0x0010) == 0x0010){
			//finish checksum calculation 
			if( (io_data16 & 0x0020) == 0x0020 ){
				fprintf(stderr,"device%d:Read IO(SUM_CHECK) error\n",device_no);
				i_err = ERR_RD_CHKSUM;
				goto end;
			}
			break;
		}
	}
	//send stop sumcheck
	io_data16 = (unsigned short)0x0013;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND STOP) error\n",device_no);
		i_err = ERR_WR_SNDSTP;
		goto end;
	}
	if(tmo == CHECK_TMO){
			fprintf(stderr,"device%d:sum check time out\n",device_no);
			i_err = ERR_TMO;
			goto end;
	}else if((io_data16 & 0x0020) == 0x0020){
			fprintf(stderr,"device%d:sum check error\n",device_no);
			i_err = ERR_SUMCHK;
			goto end;
	}else{
		fprintf(stdout,"device%d:sum check ok\n",device_no);
	}
	

	//fifo reset
	io_data16 = (unsigned short)0x80bc;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		i_err = ERR_WR_FIFO;
		goto end;
	}
	io_data16 = (unsigned short)0x0000;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		i_err = ERR_WR_FIFO;
		goto end;
	}
	io_data32 = (unsigned int)file_size;
	if(iWrIO(dfd, 0x4018, 32, &io_data32) == -1){
		fprintf(stderr,"device%d:Write IO(SIZE_SET) error\n",device_no);
		i_err = ERR_WR_SETSIZE;
		goto end;
	}
	//send start write flash
	io_data16 = (unsigned short)0x0000;
	if(iRdIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND_START) error\n",device_no);
		i_err = ERR_WR_SNDSTT;
		goto end;
	}
	
	io_data16 = (unsigned short)0x0103;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND START) error\n",device_no);
		i_err = ERR_WR_SNDSTT;
		goto end;
	}
	//flash write
	io_data16 = (unsigned short)0x0001;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FLASH_WRITE) error\n",device_no);
		i_err = ERR_WR_FLS;
		goto end;
	}
	//wait
	for(tmo = 0; tmo < CHECK_TMO; tmo ++){
		usleep(CHECK_TICK);
		io_data16 = (unsigned short)0x0000;
		if(iRdIO(dfd, 0x4028, 16, &io_data16) == -1){
			fprintf(stderr,"device%d:Read IO(FLASH_WRITE) error\n",device_no);
			i_err = ERR_RD_FLS;
			goto end;
		}
		if(io_data16 == (unsigned short)0x0d0e){
			if(io_data16_bk != io_data16){
				io_data16_bk = io_data16;
				fprintf(stdout,"device%d:config flash erase >",device_no);
				fflush(stdout);
			}else{
				fprintf(stdout,">");
				fflush(stdout);
			}
		}else if(io_data16 == (unsigned short)0x1112){
			if(io_data16_bk != io_data16){
				io_data16_bk = io_data16;
				fprintf(stdout,"\ndevice%d:config flash write >",device_no);
				fflush(stdout);
			}else{
				fprintf(stdout,">");
				fflush(stdout);
			}
		}
		io_data16 = (unsigned short)0x0000;
		if(iRdIO(dfd, 0x4000, 16, &io_data16) == -1){
			fprintf(stderr,"device%d:Read IO(FLASH_WRITE) error\n",device_no);
			i_err = ERR_RD_FLS;
			goto end;
		}
		if((io_data16 & 0x0004) == 0x0004){
			break;
		}
	}
	fprintf(stdout,"\n");
	//send stop write flash
	io_data16 = (unsigned short)0x0013;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND STOP) error\n",device_no);
		i_err = ERR_WR_SNDSTP;
		goto end;
	}
	if(tmo == CHECK_TMO){
			fprintf(stderr,"device%d:config flash write time out\n",device_no);
			i_err = ERR_TMO;
			goto end;
	}else if((io_data16 & 0x0080) == 0x0080){
			fprintf(stderr,"device%d:config flash write error\n",device_no);
			i_err = ERR_WRFLS_FIN;
			goto end;
	}else{
		//none
	}

	fprintf(stdout,"device%d:config flash write ok!\n",device_no);
	fprintf(stdout,"device%d:-Board_S/N[%lu] -File_name[%s] -File_size[%d]byte -File_mtime[%s] -File_md5sum[%s]\n"
					,device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
	syslog(LOG_INFO,"config file flash write ok! -device_file[#%d] -S/N[%lu] -name[%s] -size[%d]byte -mtime[%s] -md5sum[%s]"
					,device_no, ui64_sn, config_file, file_size, modtime, cMd5Buf);
#if 0
	io_data16 = (unsigned short)0x0000;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(IPROG) error\n",device_no);
		goto end;
	}
	usleep(10*1000);

	io_data16 = (unsigned short)0x0100;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(IPROG) error\n",device_no);
		goto end;
	}
	usleep(10*1000);
#endif
	fprintf(stdout,"<<Please Shutdown Server!!>>\n");
	fprintf(stdout,"(Please do Not use \"reboot\" command for this purpose.)\n");
	
	ret = 0;
end :
	if ( i_err != 0 ) vOutErrSyslog( i_err );

	if(mp != NULL){
		 munmap(mp,SND_BUF_SIZE);
		 mp = NULL;
	}
	if(dfd != -1){
		close(dfd);
		dfd = -1;
	}
	if(infp != NULL){
		fclose(infp);
		infp = NULL;
	}
	
	return ret;
}
