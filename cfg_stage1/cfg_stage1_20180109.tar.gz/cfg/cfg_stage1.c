/**@module@*********************************************************************

	Project : DRXP 
	Target	: DRXP Board Config FPGA-Flash

	Author	: k.shimoyama
	Date	: 2016/10/13

	@name	: cfg_stage1.c
 	@summary:driver source file

*********************************************************************@module@**/
/*- Revision History -----------------------------------------------------
	VER0.0.1 [2016/10/13]
------------------------------------------------------------------------*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <string.h>
#include <sys/ioctl.h>
#include <stdlib.h>
#include <signal.h>
#include <unistd.h>
#include <ctype.h>

#include "drxpd.h"

#define SND_BUF_SIZE 146800640
#ifndef DRXPD_SND_MAX
#define DRXPD_SND_MAX 144000000
#endif

#define DEVICE0_PATH "/dev/drxpd0"
#define DEVICE1_PATH "/dev/drxpd1"

//IOWrite
int iWrIO(int dfd, unsigned int offset, int size, void *pval)
{
	ST_DRXPD_WRDAT     wrdat;

	if((size != 16) && (size != 32) && (size != 64)){
		fprintf(stderr,"Write IO prm error!\n");
		return -1;
	}
	
	wrdat.io_address = offset;
	wrdat.access_size = (unsigned char)(size/8);
	memcpy(&wrdat.WrValue[0],pval,size/8);
	if(ioctl( dfd, WR_IO, &wrdat ) < 0){
		fprintf(stderr,"write IO error!\n");
		return -1;
	}else{
		return 0;
	}

}
//IORead
int iRdIO(int dfd,unsigned int offset, int size, void *pval)
{
	ST_DRXPD_RDDAT     rddat;

	if((size != 16) && (size != 32) && (size != 64)){
		fprintf(stderr,"Raed IO prm error!\n");
		return -1;
	}
	rddat.io_address = offset;
	rddat.access_size = (unsigned char)(size/8);
	if(ioctl( dfd, RD_IO, &rddat ) < 0){
		fprintf(stderr,"read IO error!\n");
		memset(pval,0,size/8);
		return -1;
	}else{
		memcpy(pval,&rddat.RdValue[0],size/8);
		return 0;
	}
}

//
//main
//
int main( int argc, char *argv[] ){

	int opt;
	int device_no = -1;
	char config_file[256];
	FILE *infp = NULL;
	int dfd = -1;
	unsigned char *mp = NULL;
	int ret = -1;
	int file_size = 0;
	unsigned short io_data16 = 0;
	unsigned short io_data16_bk = 0;
	unsigned int io_data32 = 0;
	int result = 0;
	int tmo = 0;
	int devno = 0;
	char devpath[32] = {0};
#define CHECK_TICK (1000*1000)	//1s
#define CHECK_TMO  (30)			//30s


	memset(config_file,0,sizeof(config_file));
	while ((opt = getopt(argc, argv, "n:f:")) != -1) {
		switch (opt) {
			case 'n':
				#if 0
				if(atoi(optarg) == 0){ 
					device_no = 0;
				}else if(atoi(optarg) == 1){
					device_no = 1;
				}
				#endif
				device_no=atoi(optarg);	
				if( (device_no < 0) || (device_no > 3) ){
	  				fprintf(stderr,"format) ./debag_apl -n <deviceno 0-3> -f <config file> \n");
					return ret; //ng
				}
				break;
			case 'f':
				strncpy(config_file,optarg,sizeof(config_file)-1);
				break;
			default: /* '?' */
	  			fprintf(stderr,"format) ./debag_apl -n <deviceno 0-3> -f <config file> \n");
				return ret; 
		}   
	}  

	if(( device_no == -1) || ( strlen(config_file) <= 0 )){
	  fprintf(stderr,"format) ./debag_apl -n <deviceno 0-3> -f <config file> \n");
	  return ret;
	}

	//config file open!
	infp = fopen(config_file,"rb");
	if( infp == NULL ){
		fprintf(stderr,"%s:file open error\n",config_file);
		return  ret;
	}
	
	//device open!
	if( snprintf(devpath, sizeof(devpath), "/dev/drxpd%d", device_no) < 0 )
	{
		fprintf(stderr, "fail to create device path string.\n");
		goto end;	
	}
	dfd = open( devpath, O_RDWR );
	//dfd = open( (device_no == 0 ?  DEVICE0_PATH : DEVICE1_PATH), O_RDWR );
	if( dfd == -1 ){
		fprintf(stderr,"device%d:open error.(path:%s).\n",device_no, devpath);
		goto end;
	}

	//mmap!
	mp = mmap(NULL, SND_BUF_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, dfd, 0); 
	if( mp == (void *) -1){
		mp = NULL;
		fprintf(stderr,"device%d:mmap error\n",device_no);
		goto end;
	}
	//config data copy!
	file_size = fread( mp, sizeof(unsigned char), SND_BUF_SIZE, infp );
	if(ferror(infp)){
		fprintf(stderr,"%s:file read error\n",config_file);
		goto end;
	}else{
		fprintf(stdout,"config file is %s:size = %d byte\n",config_file,file_size);
	}

	//send size set!
	if( ioctl(dfd, DRXPD_SET_SNDSIZ, DRXPD_SND_MAX ) == -1){
		fprintf(stderr,"device%d:ioctl(DRXPD_SET_SNDSIZ) error\n",device_no);
		goto end;
	}

	//config mode set!
	io_data16 = (unsigned short)0x0001;
	if(iWrIO(dfd, 0x378, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(CONFIG MODE) error\n",device_no);
		goto end;
	}
	io_data16 = 0;
	if(iRdIO(dfd, 0x378, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Read IO(CONFIG MODE) error\n",device_no);
		goto end;
	}else{
		if(io_data16 != 0x0001){
			fprintf(stderr,"device%d:Read IO(CONFIG MODE) verify error\n",device_no);
			goto end;
		}else{
			fprintf(stdout,"device%d:Read IO(CONFIG MODE) set ok\n",device_no);
		}
	}
	
	if( ioctl(dfd, DRXPD_INIT, &result ) == -1){
		fprintf(stderr,"device%d:ioctl(DRXPD_INIT) error\n",device_no);
		goto end;
	}
	if(result == -1){
		fprintf(stderr,"device%d:ioctl(DRXPD_INIT) result error\n",device_no);
		goto end;
	}
	//fifo reset
	io_data16 = (unsigned short)0x80bc;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		goto end;
	}
	io_data16 = (unsigned short)0x0000;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		goto end;
	}
	io_data32 = (unsigned int)file_size;
	if(iWrIO(dfd, 0x4018, 32, &io_data32) == -1){
		fprintf(stderr,"device%d:Write IO(SIZE_SET) error\n",device_no);
		goto end;
	}
	io_data16 = (unsigned short)0x0000;
	if(iRdIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND_START) error\n",device_no);
		goto end;
	}
	
	io_data16 = (unsigned short)0x0103;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND START) error\n",device_no);
		goto end;
	}

	//sumcheck
	io_data16 = (unsigned short)0x0003;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SUM_CHECK) error\n",device_no);
		goto end;
	}
	//wait
	for(tmo = 0; tmo < CHECK_TMO; tmo ++){
		usleep(CHECK_TICK);
		io_data16 = (unsigned short)0x0000;
		if(iRdIO(dfd, 0x4000, 16, &io_data16) == -1){
			fprintf(stderr,"device%d:Read IO(SUM_CHECK) error\n",device_no);
			goto end;
		}
		if((io_data16 & 0x0010) == 0x0010){
			break;
		}
	}
	//send stop sumcheck
	io_data16 = (unsigned short)0x0013;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND STOP) error\n",device_no);
		goto end;
	}
	if(tmo == CHECK_TMO){
			fprintf(stderr,"device%d:sum check time out\n",device_no);
			goto end;
	}else if((io_data16 & 0x0020) == 0x0020){
			fprintf(stderr,"device%d:sum check error\n",device_no);
			goto end;
	}else{
		fprintf(stdout,"device%d:sum check ok\n",device_no);
	}
	

	//fifo reset
	io_data16 = (unsigned short)0x80bc;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		goto end;
	}
	io_data16 = (unsigned short)0x0000;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FIFO_RESET) error\n",device_no);
		goto end;
	}
	io_data32 = (unsigned int)file_size;
	if(iWrIO(dfd, 0x4018, 32, &io_data32) == -1){
		fprintf(stderr,"device%d:Write IO(SIZE_SET) error\n",device_no);
		goto end;
	}
	//send start write flash
	io_data16 = (unsigned short)0x0000;
	if(iRdIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND_START) error\n",device_no);
		goto end;
	}
	
	io_data16 = (unsigned short)0x0103;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND START) error\n",device_no);
		goto end;
	}
	//flash write
	io_data16 = (unsigned short)0x0001;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(FLASH_WRITE) error\n",device_no);
		goto end;
	}
	//wait
	for(tmo = 0; tmo < CHECK_TMO; tmo ++){
		usleep(CHECK_TICK);
		io_data16 = (unsigned short)0x0000;
		if(iRdIO(dfd, 0x4028, 16, &io_data16) == -1){
			fprintf(stderr,"device%d:Read IO(FLASH_WRITE) error\n",device_no);
			goto end;
		}
		if(io_data16 = (unsigned short)0x0d0e){
			if(io_data16_bk != io_data16){
				io_data16_bk = io_data16;
				fprintf(stdout,"device%d:config flash erase >",device_no);
				fflush(stdout);
			}else{
				fprintf(stdout,">",device_no);
				fflush(stdout);
			}
		}else if(io_data16 = (unsigned short)0x1112){
			if(io_data16_bk != io_data16){
				io_data16_bk = io_data16;
				fprintf(stdout,"\ndevice%d:config flash write >",device_no);
				fflush(stdout);
			}else{
				fprintf(stdout,">",device_no);
				fflush(stdout);
			}
		}
		io_data16 = (unsigned short)0x0000;
		if(iRdIO(dfd, 0x4000, 16, &io_data16) == -1){
			fprintf(stderr,"device%d:Read IO(FLASH_WRITE) error\n",device_no);
			goto end;
		}
		if((io_data16 & 0x0004) == 0x0004){
			break;
		}
	}
	fprintf(stdout,"\n");
	//send stop write flash
	io_data16 = (unsigned short)0x0013;
	if(iWrIO(dfd, 0x300, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(SND STOP) error\n",device_no);
		goto end;
	}
	if(tmo == CHECK_TMO){
			fprintf(stderr,"device%d:config flash write time out\n",device_no);
			goto end;
	}else if((io_data16 & 0x0080) == 0x0080){
			fprintf(stderr,"device%d:config flash write error\n",device_no);
			goto end;
	}else{
		//none
	}

	fprintf(stdout,"device%d:config flash write ok!\n",device_no);
#if 0
	io_data16 = (unsigned short)0x0000;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(IPROG) error\n",device_no);
		goto end;
	}
	usleep(10*1000);

	io_data16 = (unsigned short)0x0100;
	if(iWrIO(dfd, 0x4000, 16, &io_data16) == -1){
		fprintf(stderr,"device%d:Write IO(IPROG) error\n",device_no);
		goto end;
	}
	usleep(10*1000);
#endif
	fprintf(stdout,"<<Please Reboot Server!!>>\n",device_no);
	
	ret = 0;
end :
	if(mp != NULL){
		 munmap(mp,SND_BUF_SIZE);
		 mp = NULL;
	}
	if(dfd != -1){
		close(dfd);
		dfd = -1;
	}
	if(infp != NULL){
		fclose(infp);
		infp = NULL;
	}
	
	return ret;
}
