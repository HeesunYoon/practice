#!/bin/sh

cp drxp-pd /etc/init.d/drxp-pd
chmod 755 /etc/init.d/drxp-pd
if [ ! -f /etc/rc5.d/S99drxp-pd ] ; then
  ln -s  /etc/init.d/drxp-pd /etc/rc5.d/S99drxp-pd
fi


if [ ! -d /usr/lib/drxp-pd/ ] ; then
  mkdir /usr/lib/drxp-pd
  chmod 755 /usr/lib/drxp-pd
fi

cp -i drxp_proto_1.bit /usr/lib/drxp-pd/
chmod 644 /usr/lib/drxp-pd/drxp_prod_1.bit
cp -i  drxp_proto_2.bit /usr/lib/drxp-pd/
chmod 644 /usr/lib/drxp-pd/drxp_prod_2.bit


cp mcap /usr/bin/mcap
chmod 755 /usr/bin/mcap

