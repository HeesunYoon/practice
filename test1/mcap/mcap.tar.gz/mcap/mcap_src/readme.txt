
  This software incorporates following:
   1.the software developed independently by or for  Elecs Industry Co., Ltd.
   2.the software licensed under the GNU General Public License, Version 2 (GPL V2)
	 COPYING
   3.open sourced software other than the software licensed under the GPL v2
  
  For the software categorized as "2", 
  please refer to the terms and conditions ofGPL v2, as the case may be at
  https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
 
  For the software categorized as "3",
  includes software developed by the University of California, Berkeley and its contributors.(BSD)
  
  The GPL software is distributed in the hope that it will be useful, but WITHOUT ANYWARRANTY,
  without even the implied warranty of MERCHANTABILITY or FITNESS FOR PARTICULAR PURPOSE.

