/******************************************************************************
* Copyright (C) 2014-2015 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* XILINX CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/
/*****************************************************************************/
/**
*
* @file mcap.c
* MCAP Interface Library Test Application
*
******************************************************************************/
#include "mcap_lib.h"

static const char options[] = "x:y:p:C:rmfdvHhDa::";
static char help_msg[] =
"Usage: mcap [options]\n"
"\n"
"Options:\n"
"\t-x\t\tSpecify MCAP Device Id in hex (MANDATORY)\n"
"\t-y\t\tSpecify MCAP Revision Id in hex\n"
"\t-p    <file>\tProgram Bitstream (.bin/.bit/.rbt)\n"
"\t-C    <file>\tPartial Reconfiguration Clear File(.bin/.bit/.rbt)\n"
"\t-r\t\tPerforms Simple Reset\n"
"\t-m\t\tPerforms Module Reset\n"
"\t-f\t\tPerforms Full Reset\n"
"\t-D\t\tRead Data Registers\n"
"\t-d\t\tDump all the MCAP Registers\n"
"\t-v\t\tVerbose information of MCAP Device\n"
"\t-h/H\t\tHelp\n"
"\t-a <address> [type [data]]  Access Device Configuration Space\n"
"\t\t      here type[data] - b for byte data [8 bits]\n"
"\t\t      here type[data] - h for half word data [16 bits]\n"
"\t\t      here type[data] - w for word data [32 bits]\n"
"\n"
;

#define MAX_MDEV 16

int main(int argc, char **argv)
{
	struct mcap_dev *mdev;
	int i, modreset = 0, fullreset = 0, reset = 0;
	int program = 0, verbose = 0, device_id = 0;
	int revision_id = 0;
	int data_regs = 0, dump_regs = 0, access_config = 0;
	int programconfigfile = 0;

	
	struct mcap_dev *mdevn[MAX_MDEV];
	struct pci_dev *pdev = NULL;
	int mdev_cnt= 0;
	int j;
	int ierr=0;
	char *filename = NULL;
	int aind = 0;

	while ((i = getopt(argc, argv, options)) != -1) {
		switch (i) {
		case 'a':
			if(optind>4)aind = optind - 4;
			access_config = 1;
			break;
		case 'd':
			dump_regs = 1;
			break;
		case 'm':
			modreset = 1;
			break;
		case 'f':
			fullreset = 1;
			break;
		case 'r':
			reset = 1;
			break;
		case 'D':
			data_regs = 1;
			break;
		case 'h':
		case 'H':
			printf("%s", help_msg);
			return 1;
		case 'C':
			programconfigfile = 1;
			filename = optarg;
			break;
		case 'p':
			program = 1;
			filename = optarg;
			break;
		case 'v':
			verbose++;
			break;
		case 'x':
			device_id = (int) strtol(optarg, NULL, 16);
			break;
		case 'y':
			revision_id = (int) strtol(optarg, NULL, 16);
			break;
		default:
			printf("%s", help_msg);
			return 1;
		}
	}

	if (!device_id) {
		printf("No device id specified...\n");
		printf("%s", help_msg);
		return 1;
	}

	
	//mdev = (struct mcap_dev *)MCapLibInit(device_id);
	
	mdevn[0] = NULL;
	mdev = (struct mcap_dev *)MCapLibInitN(device_id,revision_id,pdev);
	while(mdev && mdev_cnt < MAX_MDEV){
		mdevn[mdev_cnt] = mdev;
		pdev = mdev->pdev;
		mdev_cnt++;
		mdev = (struct mcap_dev *)MCapLibInitN(device_id,revision_id,pdev);
	}
	mdev = mdevn[0];
	
	if (!mdev)
		return 1;

	if (verbose) {
		for(i=0;i<mdev_cnt;i++){
			mdev = mdevn[i];
			ierr |= MCapShowDevice(mdev, verbose);
		}
		goto free;
	}

	if (access_config) {
		//if (argc < 6) {
		if (argc - aind < 6) {
			printf("%s", help_msg);
			goto free;
		}
		printf("aind = %d\n",aind);
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			if (ierr|=MCapAccessConfigSpace(mdev, argc-aind, &argv[aind]))
				printf("%s", help_msg);
		}
		goto free;
	}

	if (fullreset) {
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			ierr|=MCapFullReset(mdev);
		}
		goto free;
	}

	if (modreset) {
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			ierr|=MCapModuleReset(mdev);
		}
		goto free;
	}

	if (reset) {
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			ierr|=MCapReset(mdev);
		}
		goto free;
	}

	if (programconfigfile) {
		if (argc > 6)
			mdev->is_multiplebit = 1;
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];

			//ierr|=MCapConfigureFPGA(mdev, argv[4], EMCAP_PARTIALCONFIG_FILE);
			ierr|=MCapConfigureFPGA(mdev, filename, EMCAP_PARTIALCONFIG_FILE);
		}
		if(!mdev->is_multiplebit)
			goto free;
	}

	if (program) {
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			//if (argc > 6)
			//	ierr|=MCapConfigureFPGA(mdev, argv[6], EMCAP_CONFIG_FILE);
			//else
			//	ierr|=MCapConfigureFPGA(mdev, argv[4], EMCAP_CONFIG_FILE);
			ierr|=MCapConfigureFPGA(mdev, filename, EMCAP_CONFIG_FILE);
		}
		goto free;
	}

	if (dump_regs) {
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			MCapDumpRegs(mdev);
		}
		goto free;
	}

	if (data_regs) {
		for(j=0;j<mdev_cnt;j++){
			mdev = mdevn[j];
			MCapDumpReadRegs(mdev);
		}
		goto free;
	}

	if (i == -1 && argc == 1)
		ierr|=MCapShowDevice(mdev, 0);

free:
	MCapLibFree(mdev);

	return ierr;
}
