#!/bin/sh

cp drxp /etc/init.d/drxp
chmod 755 /etc/init.d/drxp
if [ ! -f /etc/rc5.d/S99drxp ] ; then
  ln -s  /etc/init.d/drxp /etc/rc5.d/S99drxp
fi

if [ ! -f /etc/rc3.d/S99drxp ] ; then
  ln -s  /etc/init.d/drxp /etc/rc3.d/S99drxp
fi

if [ ! -d /usr/lib/drxp/ ] ; then
  mkdir /usr/lib/drxp
  chmod 755 /usr/lib/drxp
fi

#cp drxp_proto_1.bit /usr/lib/drxp/
#chmod 644 /usr/lib/drxp/drxp_proto_1.bit
cp drxp_proto_2.bit /usr/lib/drxp/
chmod 644 /usr/lib/drxp/drxp_proto_2.bit


cp mcap /usr/bin/mcap
chmod 755 /usr/bin/mcap

